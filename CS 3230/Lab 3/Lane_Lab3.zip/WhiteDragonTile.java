/*
 * Andrew Lane
 * CS3230 - Lab3
 * 10/14/15
*/

public class WhiteDragonTile extends Tile {
    @Override
    public String toString() {
        return "White Dragon";
    }
}