/*
 * Andrew Lane
 * CS3230 - Lab3
 * 10/14/15
*/

public class Bamboo1Tile extends PictureTile {

    public Bamboo1Tile() {
        super("sparrow");
    }

    @Override
    public String toString()
    {
        return "Bamboo 1";
    }
}