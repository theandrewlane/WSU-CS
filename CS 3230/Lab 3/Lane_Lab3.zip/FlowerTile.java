/*
 * Andrew Lane
 * CS3230 - Lab3
 * 10/14/15
*/

public class FlowerTile extends PictureTile {

    public FlowerTile(String name) {
        super(name);
    }
}