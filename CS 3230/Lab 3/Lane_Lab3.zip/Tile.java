/*
 * Andrew Lane
 * CS3230 - Lab3
 * 10/14/15
*/

abstract public class Tile {
    public boolean matches(Tile other) {
        return other != null && other.getClass() == this.getClass();
    }
}