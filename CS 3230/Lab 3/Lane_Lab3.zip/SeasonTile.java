/*
 * Andrew Lane
 * CS3230 - Lab3
 * 10/14/15
*/

public class SeasonTile extends PictureTile{
    public SeasonTile(String name) {
        super(name);
    }
}