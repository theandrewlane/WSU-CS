#include <stddef.h>

int main() {
    int *intPtr = NULL;

    *intPtr = 0;
    return 0;
}
