#include <stdlib.h>
#include <stdio.h>

int main(){
    int *ptr = (int *) malloc(1024);
            return 0;

}