package com.theandrewlane.cs2130.project4;

// Boolean Matrix Class
public class BMat {
    // Instance variables
    public int M[][];
    public int SIZE;

    // Boolean matrix constructors

    public BMat(int s) {
        SIZE = s;
        M = new int[SIZE][SIZE];
        // Fill M with zeros
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                M[r][c] = 0;
            }
        }
    }

    public BMat(int[][] B) {
        SIZE = B.length;
        M = new int[SIZE][SIZE];
        // Copy matrix B values into M
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                if (B[r][c] == 0)
                    M[r][c] = 0;
                else
                    M[r][c] = 1;
            }
        }
    }

    // Boolean matrix methods

    public void show() {
        System.out.println(); // Clean up output
        // Display matrix
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                System.out.print("  " + M[r][c]);
            }
            System.out.println();
        }
        //Make the output cleaner
        System.out.println("\n---------------------------------------\n");
        return;
    }

    public boolean isEqual(BMat M2) {
        // Check if current matrix equals matrix M2
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                if (this.M[r][c] != M2.M[r][c])
                    return false;
            }
        }
        return true;
    }

    public int trace() {
        // Sum of main diagonal values
        int diag = 0;
        for (int r = 0; r < SIZE; r++)
            diag = diag + M[r][r];
        return diag;
    }

    public int arrows() {
        // No. of 1's in matrix
        int narrows = 0;
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                narrows = narrows + M[r][c];
            }
        }
        return narrows;
    }

    public int indegree(int K) {
        // Number of arrows INTO node K of digraph
        // Nodes are numbered 0,1,2,...,SIZE-1
        int colsum = 0;
        for (int r = 0; r < SIZE; r++)
            colsum = colsum + M[r][K];
        return colsum;
    }

    public BMat complement() {
        // Logical NOT of current matrix
        BMat W1 = new BMat(SIZE);
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                if (this.M[r][c] == 0)
                    W1.M[r][c] = 1;
                else
                    W1.M[r][c] = 0;
            }
        }
        return W1;
    }

    public BMat join(BMat M2) {
        // Logical OR of current matrix with matrix M2
        BMat W1 = new BMat(SIZE);
        for (int r = 0; r < SIZE; r++) {
            for (int c = 0; c < SIZE; c++) {
                W1.M[r][c] = this.M[r][c] | M2.M[r][c];
            }
        }
        return W1;
    }

    public BMat power(int N) {
        // Raise current matrix to Boolean Nth power (N >= 1)
        BMat W1 = new BMat(this.M);
        BMat W2 = new BMat(this.M);
        for (int k = 2; k <= N; k++) {
            W1 = W1.product(W2);
        }
        return W1;
    }

    public BMat rclosure() {
        // Reflexive closure of current matrix
        BMat W1 = new BMat(this.M);
        // Put 1's on main diagonal
        for (int r = 0; r < SIZE; r++)
            W1.M[r][r] = 1;
        return W1;
    }

    public BMat sclosure() {
        // Symmetric closure of current matrix
        BMat W1 = new BMat(this.M);
        BMat W2 = W1.transpose();
        W1 = W1.join(W2);
        return W1;
    }

    // *********************************
    // Project #4 functions to add
    // *********************************

    //Working!!
    public int outdegree(int K) {
        // Number of arrows FROM node K of digraph
        // Nodes are numbered 0,1,2,...,SIZE-1
        int rowSum = 0;
        for (int i = 0; i < SIZE; i++)
            rowSum = rowSum + M[K][i];
        return rowSum;
    }


    //TODO Verify dis one
    public BMat meet(BMat M2) {
        // Logical AND of current matrix with input matrix
        BMat M1 = new BMat(SIZE);
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++)
                M1.M[i][j] = this.M[i][j] & M2.M[i][j];
        }
        return M1;
    }

    //Working
    public BMat transpose() {
        // Transpose of current matrix
        BMat M1 = new BMat(SIZE);
        for (int r = 0; r < SIZE; r++)
            for (int c = 0; c < SIZE; c++)
                M1.M[c][r] = M[r][c];
        return M1;
    }

    //Working
    public BMat product(BMat M2) {
        // Boolean product of current matrix with matrix M2
        BMat M1 = new BMat(M2.M);
        for (int i = 0; i < SIZE; i++) {
            // compute first item
            int temp = 0;
            for (int j = 0; j < SIZE; j++) {
                temp += M[i][j] * M2.M[j][i];
            }
            for (int j = 0; j < SIZE; j++) {
                M1.M[i][j] = temp;
            }
        }
        return M1;
    }

    //Working
    public BMat tclosure() {
        // Transitive closure of current matrix (Warshall's algorithm)
        BMat W1 = new BMat(this.M);
        int i, j, k;
        for (k = 0; k < SIZE; k++) {
            for (i = 0; i < SIZE; i++) {
                for (j = 0; j < SIZE; j++) {
                    if (!(W1.M[i][j] == 1)) W1.M[i][j] = W1.M[i][k] & W1.M[k][j];
                }
            }
        }
        return W1;
    }

    //Finally working. Verified!
    public int rootnode() {
        // Root node number (if any) of current matrix
        // Nodes are numbered 0,1,2,...,SIZE-1
        int pos = -1;
        int count = 0;
        for (int col = 0; col < SIZE; col++) {
            int tmp = 0;
            for (int row = 0; row < SIZE; row++) {
                tmp = tmp + M[row][col];
            }
            if (tmp == 0) {
                pos = col;
                count++;
            }
        }
        if (count == 1) return pos;
        return -1;
    }

} // end class
