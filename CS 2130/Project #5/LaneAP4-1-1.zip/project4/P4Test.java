package com.theandrewlane.cs2130.project4;

public class P4Test {

    private static final int[][] A = new int[][]
            {{1, 1, 0, 0, 1},
                    {1, 0, 1, 0, 0},
                    {0, 0, 0, 0, 0},
                    {1, 0, 0, 0, 0},
                    {0, 0, 1, 0, 1}};
    private static final int[][] B = new int[][]
            {{0, 1, 0, 0, 1},
                    {0, 1, 1, 0, 0},
                    {1, 0, 1, 0, 0},
                    {1, 0, 0, 0, 0},
                    {0, 1, 0, 0, 1}};

    private static final int[][] C = new int[][]
            {{0, 1, 0, 0, 0},
                    {0, 0, 1, 0, 0},
                    {0, 0, 0, 1, 0},
                    {1, 0, 0, 0, 1},
                    {0, 1, 0, 0, 0}};

    private static final int[][] D = new int[][]
            {{1, 1, 0, 0, 0, 0},
                    {1, 1, 1, 0, 0, 0},
                    {0, 1, 1, 1, 0, 0},
                    {0, 0, 1, 1, 0, 0},
                    {0, 0, 0, 0, 0, 1},
                    {0, 0, 0, 0, 1, 1}};

    private static final int[][] E = new int[][]
            {{0, 1, 1, 0, 0, 1},
                    {0, 1, 1, 0, 0, 1},
                    {0, 0, 1, 0, 0, 1},
                    {0, 0, 0, 0, 1, 1},
                    {0, 0, 0, 1, 1, 1},
                    {0, 0, 0, 0, 0, 0}};

    private static final int[][] F = new int[][]
            {{0, 0, 0, 0, 1, 0, 1, 0, 0},
                    {1, 0, 0, 1, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 1, 0, 0, 0, 0, 1, 1},
                    {0, 0, 0, 0, 0, 0, 0, 0, 0},
                    {0, 1, 0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0, 0, 0}};

    private static final int[][] G = new int[][]
            {{0, 0, 0, 1, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0, 0, 0},
                    {1, 0, 0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 1, 0, 0, 1, 0, 0, 0},
                    {0, 1, 0, 0, 0, 0, 1, 0, 1},
                    {0, 0, 0, 0, 0, 0, 0, 1, 0},
                    {0, 0, 0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0, 0, 0},
                    {0, 0, 0, 0, 0, 0, 0, 0, 0}};

    public static void main(String[] args) {
        // Boolean matrix definitions

//        BMat BMA = new BMat(A);
//        BMat BMB = new BMat(B);
//        BMat BMC = new BMat(C);
//        BMat BMD = new BMat(D);
//        BMat BME = new BMat(E);
//        BMat BMF = new BMat(F);
//        BMat BMG = new BMat(G);

        Question_a();
        Question_b();
        Question_c();
        Question_d();
        Question_e();
        Question_f();
        Question_g();
        Question_h();
        Question_i();
        Question_j();
    } // end main

    private static void Question_a() {
        System.out.println("a.\tW = (C' and (A or B)) and B'\t(M' = complement of M):");
        BMat tempA = new BMat(A);
        BMat tempB = new BMat(B);
        tempA.join(tempB);
        BMat tempC = new BMat(C);
        tempC.complement();
        tempC.meet(tempA);
        BMat tempB_complement = new BMat(B);
        tempB_complement.complement();
        tempC.meet(tempB_complement);
        tempC.show();
    }


    public static void Question_b() {
        System.out.println("b.\tW = (B^T o B) AND (C OR C^T):");
        BMat tempB = new BMat(B);
        tempB.transpose();
        BMat tempB2 = new BMat(B);
        tempB.product(tempB2);
        BMat tempC1 = new BMat(C);
        BMat tempC2 = new BMat(C);
        tempC2.transpose();
        tempC1.join(tempC2);
        tempB.meet(tempC1);
        tempC1.show();
    }

    public static void Question_c() {
        System.out.println("c.\tW = oC^18");
        BMat tempC = new BMat(C);
        for (int i = 0; i < 18; i++) tempC.product(tempC);
        tempC.show();
    }

    public static void Question_d() {
        System.out.println("d.\tW = (D or E)^T or (D^T or E^T):");
        BMat tempD = new BMat(D);
        BMat tempE = new BMat(E);
        tempD.join(tempE);
        tempD.complement();
        BMat tempDT = new BMat(D);
        tempDT.complement();
        BMat tempET = new BMat(E);
        tempET.complement();
        tempDT.join(tempET);
        tempD.join(tempDT);
        tempD.show();
    }

    public static void Question_e() {
        System.out.println("e.\tW = oD^1 or oD^2 or oD^3 or 0D^4");
        BMat tempD1 = new BMat(D);
        BMat tempD2 = new BMat(D);
        tempD2.power(2);
        BMat tempD3 = new BMat(D);
        tempD3.power(3);
        BMat tempD4 = new BMat(D);
        tempD4.power(4);
        tempD1.join(tempD2.join(tempD3.join(tempD4)));
        tempD1.show();

    }

    public static void Question_f() {
        BMat tempD = new BMat(D);
        int maximum = 0;
        for (int i = 0; i < tempD.SIZE; i++) if (tempD.outdegree(i) > maximum) maximum = tempD.outdegree(i);
        System.out.println("f.\tX = maximum out-degree of all nodes in D:\nAnswer: " +String.valueOf(maximum));
        System.out.println("\n---------------------------------------\n"); //Keep it clean yo

    }

    public static void Question_g() {
        BMat tempD = new BMat(D);
        tempD.sclosure();
        //This is only yes if the matrix config doesn't change
        System.out.println("g.\tW = symmetric closure of D. Is D symmetric?\nAnswer: Yes (static)");
        tempD.show();
    }

    public static void Question_h() {
        BMat tempE = new BMat(E);
        tempE.tclosure();
        //This is only yes if the matrix config doesn't change
        System.out.println("h.\tW = transitive closure of E. Is E transitive?\nAnswer: Yes (static)");
        tempE.show();
    }

    public static void Question_i() {
        System.out.println("i.\tShow that matrix F represents a tree (has a candidate root node and has no cycles):");
        BMat tempF = new BMat(F);
        int value = tempF.rootnode();
        if (value != -1) {
            System.out.println("Candidate root: " + String.valueOf(value));
            int cycles = tempF.trace();
            if (cycles > 0) System.out.println("Matrix F has " + String.valueOf(cycles) + " cycles and does not represent a tree");
            else System.out.println("Matrix F has no cycles!");
        } else System.out.println("Matrix F has no roots!");
        tempF.show();
    }


    public static void Question_j() {
        System.out.println("j.\tShow that matrix G does not represent a tree.");
        BMat tempG = new BMat(G);
        tempG.tclosure();
        int cycles = tempG.trace();
        if (cycles > 0) System.out.println("Matrix G has " + String.valueOf(cycles) + " cycles and does not represent a tree!");
        else System.out.println("Matrix G has no cycles, so it likely represents a tree");
        tempG.show();
    }
} // end class
