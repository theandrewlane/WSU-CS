package com.theandrewlane.cs2130.project3;

import static com.theandrewlane.cs2130.project3.DProb.*;

/**
 * Created by andrewlane on 2/22/17.
 */
public class DProbTest {

    public static void main(String[] args) {
        PartB1();
        PartB2();
        PartB3();
        PartB4();
        PartB5();
    }

    private static void PartB1() {
        System.out.println("\n------------------ #1 ------------------");
        System.out.println("A department contains 33 employees. The manager is going to randomly draw 4 employees and give each one a prize.");
        System.out.println("How many ways can the 4 employees be drawn if the order in which they are drawn matters or doesn't");
        System.out.println("a.\tEmployees can be drawn: " + Combinations(33, 4) + " different ways if order doesn't matter");
        System.out.println("b.\tEmployees can be drawn: " + Permutations(33, 4) + " different ways if order DOES matter");
    }

    private static void PartB2() {
        System.out.println("\n------------------ #2 ------------------");
        System.out.println("Suppose that the CS Dept at Happy Valley State College has two computer labs. Lab-A contains 50 PC's and Lab-B contains 30 PC's. " +
                "Nine of the Lab-A PC's and 4 of the Lab-B PC's have been infected with spyware. " +
                "\nA sample of PC 's will be inspected to check for spyware.");
        System.out.println("a.\t8 Lab-A machines are drawn, the probability that none of the PCs in the sample are infected is: " + HyperGeometric(80, 50, 8, 0));
        System.out.println("b.\t8 Lab-B machines are drawn, the probability that none of the PCs in the sample are infected is: " + HyperGeometric(80, 30, 8, 0));
        System.out.println("c.\tA sample of 4 Lab-A machines is drawn, and a sample of 4 Lab-B machines are drawn - The probability that non of the PCs are infected is: "+ (HyperGeometric(80, 50, 4, 0) + HyperGeometric(80, 30, 4, 0)));
        System.out.println("d.\t8 PCs are drawn from a sample of 80 Lab-A and 80 Lab-B machines, the probability the none of the PCs are infected is: " + Binomial(80, 80, 8));
    }

    private static void PartB3() {
        System.out.println("\n------------------ #3 ------------------");
        System.out.println("A munitions warehouse contains 71 bombs,of which 5 are defective. A sample of 10 bombs will be drawn and tested.");
        System.out.println("a.\tThe probability that the sample will contain exactly 2 defective bombs is: " + HyperGeometric(71, 5, 10, 2));
        System.out.println("b.\tThe probability that the sample will contain less than 2 defective bombs is: " + HyperGeometric(71, 5, 10, 8));
    }

    private static void PartB4() {
        System.out.println("\n------------------ #4 ------------------");
        System.out.println("Suppose that the same munitions warehouse containsa very large number of hand grenades, of which 6.9% are defective. A sample of 30 grenades will be drawn and tested.");
        System.out.println("a.\tThe probability that the sample will contain exactly 3 defective grenades is: " + Binomial(6.9, 30, 3));
        System.out.println("b.\tThe probability that the sample will contain less than 3 defective grenades is: " + Binomial(6.9, 30, 2));
    }

    private static void PartB5() {
        System.out.println("\n------------------ #5 ------------------");
        System.out.println("Suppose that the munitions warehouse has just received a large shipment of a new, higher-quality handgrenade. " +
                "Suppose that only 2.6% of the grenades in the shipment are defective. A sample of 125 grenades will bedrawn and tested.");
        System.out.println("Binomial Distribution Approach:");
        System.out.println("a.\tThe probability that the sample will contain exactly 4 defective grenades is: "  + Binomial(2.6, 125, 4));
        System.out.println("b.\tThe probability that the sample will contain less than 4 defective grenades is: " + Binomial(6.9, 30, 2));
        System.out.println("\nPiosson Distribution Approach:");
        System.out.println("a.\tThe probability that the sample will contain exactly 4 defective grenades is: " + Poisson(2.6, 4));
        System.out.println("b.\tThe probability that the sample will contain less than 4 defective grenades is: " + Poisson(2.6, 3));
        System.out.println("\n");

    }
}
