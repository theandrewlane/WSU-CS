package com.theandrewlane.cs2130.project3;

/*
 * Andrew B Lane - W01272253
 * CS2130 - Project 3
 * 2/27/17
 */

// Discrete Probability Library
public class DProb {

    public static double Permutations(long N, long X) {
        if (X == N && X == 0) return 1.0;
        double perm = N;
        for (int i = 1; i < X; i++) {
            perm *= (double) (N - i);
        }
        return perm;
    }

    public static double Combinations(long N, long X) {
        if (X == 0 && X == N) return 1.0;
        int i = 1;
        double comb = N;
        while (i < X) {
            comb *= (double) (N - i) / (double) (i + 1);
            i++;
        }
        return comb;
    }

    public static double HyperGeometric(long Np, long Xp, long N, long X) {
        return (Combinations(Xp, X) * Combinations(Np - Xp, N - X)) / Combinations(Np, N);
    }

    public static double Binomial(double P, long N, long X) {
        return Combinations(N, X) * (Math.pow(P, (double) X)) * Math.pow(1 - P, (double) (N - X));
    }

    public static double Poisson(double Xmean, long X) {
        return Math.pow(Math.E, -1 * Xmean) * (Math.pow(Xmean, (double) X) / (X - 1) * X);
    }

}