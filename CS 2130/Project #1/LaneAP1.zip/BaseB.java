/*
 * Andrew B Lane - W01272253
 * CS2130 - Project 1
 * 1/27/147
 */

import java.util.Arrays;
import java.util.Stack;

public class BaseB {

    public static void main(String[] args) {
        long x1, x2;

        if (args.length >= 2) {
            x1 = Long.parseLong(args[0]);
            x2 = Long.parseLong(args[1]);
            if (x1 >= 1)
                System.out.printf("%d base %d: %s\n", x1, x2, Arrays.toString(_reverse(x1, x2)).replaceAll("[^\\d.]", ""));
        }

    }

    private static long[] _reverse(long x, long base) {
        long[] result;
        Stack<Long> values = new Stack<>();

        while (x > 0) {
            values.add(x % base);
            x = (x / base);
        }

        result = new long[values.size()];
        for (int i = 0; !values.empty(); i++)
            result[i] = values.pop();
        return result;
    }

}
