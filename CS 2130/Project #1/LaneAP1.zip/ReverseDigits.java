/*
 * Andrew B Lane - W01272253
 * CS2130 - Project 1
 * 1/27/147
 */

public class ReverseDigits {

    private final Long input;
    private final long result;
    private final String resultOutput;

    public static void main(String[] args) {
        ReverseDigits rd;
        if (args.length >= 1) {
            rd = new ReverseDigits(args[0]);
            if (rd.getInput() >= 1) {
                System.out.println(rd.getResultOutput());
            }
        }
    }

    public String getResultOutput() {
        return resultOutput;
    }

    public long getResult() {
        return result;
    }

    public Long getInput() {
        return input;
    }

    public ReverseDigits(String input) {
        this.input = Long.parseLong(input);
        this.result = _reverseDigits(this.input);
        this.resultOutput = "Reverse order of " + this.input + ": " + this.result;
    }

    private static long _reverseDigits(long x) {
        String _x = String.valueOf(x);
        if (_x.length() <= 1) return x;
        else if (_x.length() > 1) return Long.valueOf(new StringBuffer(_x).reverse().toString());
        return x;
    }
}
