/*
 * Andrew B Lane - W01272253
 * CS2130 - Project 1
 * 1/27/147
 */

public class RecursiveSeq {
    public static void main(String[] args) {
        long x;
        if (args.length >= 1) {
            x = Long.parseLong(args[0]);
            if (x >= 0) System.out.printf("Perfect number for %d: %d\n", x ,_recursiveSeq(x));
        }
    }

    private static long _recursiveSeq(long x) {
        if (x == 0) return 0;
        if (x == 1) return 1;
        return _recursiveSeq(x - 1) + _recursiveSeq(x - 2);
    }
}