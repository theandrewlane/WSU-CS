/*
 * Andrew B Lane - W01272253
 * CS2130 - Project 1
 * 1/27/17
 */

public class GCD {
    public static void main(String[] args) {
        long x1, x2;
        if (args.length >= 2) {
            x1 = Long.parseLong(args[0]);
            x2 = Long.parseLong(args[1]);
            if (x1 >= 1) System.out.printf("GCD of (%d, %d): %d\n", x1, x2, _gcd(x1, x2));
        }
    }

    private static long _gcd(long x1, long x2) {
        long tmp;
        while (x2 != 0) {
            tmp = x2;
            x2 = x1 % x2;
            x1 = tmp;
        }
        return x1;
    }
}