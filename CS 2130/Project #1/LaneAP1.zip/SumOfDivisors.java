/*
 * Andrew B Lane - W01272253
 * CS2130 - Project 1
 * 1/27/147
 */

public class SumOfDivisors {
    public static void main(String args[]) {
        final long x;
        if (args.length >= 1) {
            x = Long.parseLong(args[0]);
            if (x >= 1) System.out.printf("Sum of divisors of %d: %d\n", x, _sumOfDivisors(x));
        }
    }

    private static long _sumOfDivisors(long x) {
        long total = 0, i = 1;
        while (i < x) {
            long x1 = x / i;
            double x2 = (double) x / (double) i;
            if (x2 == x1)
                total += i;
            i++;
        }
        total += x;
        return total;
    }
}
