/*
 * Andrew B Lane - W01272253
 * CS2130 - Project 2
 * 2/5/17
 */
public class Proj2C {
    public static void main(String[] args) {
        if (args.length >= 2) {
            long n1 = Long.parseLong(args[0]);      
            final long n2 = Long.parseLong(args[1]);
            System.out.printf("\nK-numbers between %d and %d:\n", n1, n2);
            while (n1 <= n2 && n1 > 0) {
                if (KNumber(n1)) System.out.println(n1);
                n1++;
            }
        }
    }

    public static boolean KNumber(long X) {
        return (OddInt(X) && SquareInt(X) && SymmetricInt(X));
    }

    public static boolean OddInt(long X) {
        return (X % 2 != 0);
    }

    public static boolean SquareInt(long X) {
        return (Math.sqrt(X) % 1 == 0);
    }

    public static boolean SymmetricInt(long X) {
        return String.valueOf(X).equals(new StringBuilder(String.valueOf(X)).reverse().toString());
    }
}

