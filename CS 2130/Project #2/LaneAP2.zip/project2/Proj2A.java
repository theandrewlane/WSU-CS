/*
 * Andrew B Lane - W01272253
 * CS2130 - Project 2
 * 2/5/17
 */

public class Proj2A {
    public static void main(String args[]) {
        char[] gateVals = {'T', 'F'}; //create the loop
        System.out.println("Generating truth table for (~q ^ r ^ ~p) v (~(r v ~p)):");
        for (char p : gateVals)
            for (char q : gateVals)
                for (char r : gateVals) {
                    System.out.printf("|_%s_|_%s_|_%s_|\t=\t%s\n", p, q, r, LProp(p, q, r));
                }
    }

    private static char LProp(char p, char q, char r) {
        // Logical expression
        return ORlogic(ANDlogic(NOTlogic(p), ANDlogic(r, NOTlogic(q))),
                NOTlogic(ORlogic(r, NOTlogic(p))));
    }

    private static char ANDlogic(char p, char q) {
        // Logical AND function
        return (p == 'T' && q == 'T') ? 'T' : 'F';
    }

    private static char ORlogic(char p, char q) {
        // Logical OR function
        return (p == 'T' || q == 'T') ? 'T' : 'F';
    }

    private static char NOTlogic(char p) {
        // Logical NOT function
        return (p == 'T') ? 'F' : 'T';
    }
}
