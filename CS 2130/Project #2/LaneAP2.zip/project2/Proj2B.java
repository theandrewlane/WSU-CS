/*
 * Andrew B Lane - W01272253
 * CS2130 - Project 2
 * 2/8/17
 */

public class Proj2B {
    public static void main(String args[]) {
        int[] vals = {0, 1};
        System.out.println("Generating truth table for ~(X v Y)^Z v ( ~X^Y^~Z ) " +
                "v ~Z^W^(X v Y)  v X^~Y^(~W v ~Z v W v Z):\n");
        for (int x : vals)
            for (int y : vals)
                for (int z : vals)
                    for (int w : vals)
                        System.out.printf("|_%s_|_%s_|_%s_|_%s_|\t=\t%s%n", x, y, z, w, LCircuit(x, y, z, w));
    }

    private static int ANDgate(int x, int y) {
        return (x == 1 && y == 1) ? 1 : 0;
    }

    private static int ORgate(int x, int y) {
        return (x == 1 || y == 1) ? 1 : 0;
    }

    private static int NOTgate(int x) {
        return (x == 1) ? 0 : 1;
    }

    private static int LCircuit(int x, int y, int z, int w) {
        // ~(x ^ y)z
        int part1 = ANDgate(NOTgate(ANDgate(x, y)), z);

        //( ~xy~z )
        int part2 = ANDgate(ANDgate(NOTgate(x), y), NOTgate(z));

        //~zw(x + y)
        int part3 = ANDgate(ANDgate(NOTgate(z), w), ORgate(x, y));

        //x~y(~w + ~z+ w + z)
        int part4 = ANDgate(ANDgate(x, NOTgate(y)), ORgate(ORgate(NOTgate(w),
                NOTgate(z)), ORgate(w, z)));

        return ORgate(ANDgate(ANDgate(part1, part2), part3), part4);
    }
}























