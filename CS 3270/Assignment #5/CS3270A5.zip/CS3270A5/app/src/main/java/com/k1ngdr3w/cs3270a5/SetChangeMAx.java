package com.k1ngdr3w.cs3270a5;


import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 */
public class SetChangeMAx extends Fragment {


    private EditText newAmount;


    public SetChangeMAx() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rv = inflater.inflate(R.layout.fragment_set_change_max, container, false);
        MainActivity ma = (MainActivity) getActivity();
        Button save = (Button) rv.findViewById(R.id.button_newAmount);
        newAmount = (EditText) rv.findViewById(R.id.editText);
        return rv;
    }

    public double getNewAmount() {
        return Double.parseDouble(newAmount.getText().toString());
    }

}
