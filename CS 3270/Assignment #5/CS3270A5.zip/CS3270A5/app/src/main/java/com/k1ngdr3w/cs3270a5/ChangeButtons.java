package com.k1ngdr3w.cs3270a5;

import android.app.Fragment;

import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class ChangeButtons extends Fragment implements Button.OnClickListener {

    //Globals and such
    private final DecimalFormat df2 = new DecimalFormat("###.##");
    private final NumberFormat format =
            NumberFormat.getCurrencyInstance(Locale.US);
    private MainActivity ma;

    public ChangeButtons() {}

    //Add buttons and create listners
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rv = inflater.inflate(R.layout.fragment_change_buttons, container, false);

        ma = (MainActivity) getActivity();
        Button one_C = (Button) rv.findViewById(R.id.button_01C);
        Button five_C = (Button) rv.findViewById(R.id.button_05C);
        Button ten_C = (Button) rv.findViewById(R.id.button_10C);
        Button twentyFive_C = (Button) rv.findViewById(R.id.button_25C);
        Button fifty_C = (Button) rv.findViewById(R.id.button_50C);
        Button one_D = (Button) rv.findViewById(R.id.button_1D);
        Button five_D = (Button) rv.findViewById(R.id.button_5D);
        Button ten_D = (Button) rv.findViewById(R.id.button_10D);
        Button twenty_D = (Button) rv.findViewById(R.id.button_20D);
        Button fifty_D = (Button) rv.findViewById(R.id.button_50D);

        one_C.setOnClickListener(this);
        five_C.setOnClickListener(this);
        ten_C.setOnClickListener(this);
        twentyFive_C.setOnClickListener(this);
        fifty_C.setOnClickListener(this);
        one_D.setOnClickListener(this);
        five_D.setOnClickListener(this);
        ten_D.setOnClickListener(this);
        twenty_D.setOnClickListener(this);
        fifty_D.setOnClickListener(this);

        return rv;
    }

    //Do the calc math here!
    @Override
    public void onClick(View view) {
        runButtonAction(view);
    }

    private void runButtonAction(View v) {

        switch (v.getId()) {
            case R.id.button_1D:
                addAndCheck(1.00);
                break;
            case R.id.button_5D:
                addAndCheck(5.00);
                break;
            case R.id.button_10D:
                addAndCheck(10.00);
                break;
            case R.id.button_20D:
                addAndCheck(20.00);
                break;
            case R.id.button_50D:
                addAndCheck(50.00);
                break;
            case R.id.button_01C:
                addAndCheck(0.01);
                break;
            case R.id.button_05C:
                addAndCheck(0.05);
                break;
            case R.id.button_10C:
                addAndCheck(0.10);
                break;
            case R.id.button_25C:
                addAndCheck(0.25);
                break;
            case R.id.button_50C:
                addAndCheck(0.50);
                break;
        }
    }

    //Make the money look pretty
    private double formatMoney(double amount){
        return Double.valueOf(df2.format(amount));
    }

    //Check if the newly added amount is higher or lower than the target
    private void addAndCheck(Double amount) {
        double tsf = formatMoney(ma.getTotalSoFar());
        double ctm = formatMoney(ma.getChangeToMake());
        if(amount + tsf == ctm ){
            ma.cancelTimer();
            ma.createGameAlert("You were able to make the correct change.", "You did it!", "complete");
            ma.incrementCorrectChangeCount();
        }

        if(amount + tsf > ctm){
            ma.cancelTimer();
            ma.createGameAlert("You should try again.", "That's too much change.", "startOver");
        }

        else {
            ma.addToTotalSoFar(amount);
        }
    }

    /**
     * This interface must be implemented by activities that contain this
     * fragment to allow an interaction in this fragment to be communicated
     * to the activity and potentially other fragments contained in that
     * activity.
     * <p/>
     * See the Android Training lesson <a href=
     * "http://developer.android.com/training/basics/fragments/communicating.html"
     * >Communicating with Other Fragments</a> for more information.
     */
    public interface OnFragmentInteractionListener {
        // TODO: Update argument type and name
        void onFragmentInteraction(Uri uri);
    }
}
