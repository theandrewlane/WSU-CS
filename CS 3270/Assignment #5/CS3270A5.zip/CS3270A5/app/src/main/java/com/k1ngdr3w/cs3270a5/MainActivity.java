package com.k1ngdr3w.cs3270a5;

import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;


public class MainActivity extends AppCompatActivity {

    private SetChangeMAx setChangeFrag;
    private ChangeActions changeActions;
    private ChangeButtons changeButtons;
    private ChangeResults changeResults;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.zeroCount:
                zeroCorrectChangeCount();
                return true;
            case R.id.setChangeMax:
                hideFragsShowChangeSettings();
                cancelTimer();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    private void hideFragsShowChangeSettings() {
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.hide(changeActions);
        fragmentTransaction.hide(changeButtons);
        //fragmentTransaction.replace(R.id.fragment, setChangeFrag);
        fragmentTransaction.hide(changeResults);
        fragmentTransaction.show(setChangeFrag);
        fragmentTransaction.commit();

    }

    public void removeShowChangeSettings() {
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.show(changeResults);
        fragmentTransaction.show(changeButtons);
        fragmentTransaction.commit();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentManager fragmentManager = getFragmentManager();
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
        changeActions = (ChangeActions)
                getFragmentManager().findFragmentByTag("changeActionsFrag");

        changeButtons = (ChangeButtons)
                getFragmentManager().findFragmentByTag("changeButtonsFrag");

        changeResults = (ChangeResults)
                getFragmentManager().findFragmentByTag("changeResultsFrag");
        setChangeFrag = (SetChangeMAx) getFragmentManager().findFragmentByTag("changeAmountFrag");
        fragmentTransaction.hide(setChangeFrag);
        fragmentTransaction.commit();


        addShowHideListener(R.id.button_changeAmount);
        startOver();
    }


    private void addShowHideListener(int buttonId) {
        final Button button = (Button) findViewById(buttonId);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                FragmentManager fragmentManager = getFragmentManager();
                FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
                fragmentTransaction.show(changeResults);
                fragmentTransaction.show(changeButtons);
                fragmentTransaction.show(changeActions);
                fragmentTransaction.hide(setChangeFrag);
                newUserDefinedAmount(setChangeFrag.getNewAmount());
                fragmentTransaction.commit();

            }
        });
    }

    public void addToTotalSoFar(Double amount) {
        changeResults.updateChangeAmount(amount);

    }

    public void newAmount() {
        changeResults.newAmount();
    }

    private void newUserDefinedAmount(Double amount) {
        changeResults.newUserDefinedAmount(amount);
    }

    public void startOver() {
        changeResults.startOver();
    }

    public double getChangeToMake() {
        return changeResults.getChangeToMake();
    }

    public void setChangeToMake(double amount) {
        changeResults.setChangeToMake(amount);
    }

    public void cancelTimer() {
        changeResults.cancelTimer();
    }

    public void setTotalSoFar(double amount) {
        changeResults.setTotalSoFar(amount);
    }

    public void setTimerFinished(boolean boo) {
        changeResults.setTimerFinished(boo);
    }

    public double getTotalSoFar() {
        return changeResults.getTotalSoFar();
    }

    public void incrementCorrectChangeCount() {
        changeActions.incrementCorrectChangeCount();

    }

    private void zeroCorrectChangeCount() {
        changeActions.zeroCorrectChangeCount();
    }

    //Constuctor function for alerts!
    public Integer createGameAlert(String message, String title, final String opt) {

        AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                switch (opt) {
                    case "startOver":
                        startOver();
                        break;
                    case "complete":

                        break;
                    case "restart":
                        newAmount();
                        break;
                }
            }
        });
        AlertDialog myAlert = builder.create();
        myAlert.show();
        return 0;
    }
}
