package com.k1ngdr3w.cs3270a5;

import android.app.Fragment;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

public class ChangeActions extends Fragment implements Button.OnClickListener {
    private TextView correctChangeCount;
    private Integer ccc;
    private MainActivity ma;

    @Override
    public void onPause(){
        super.onPause();
        SharedPreferences prefs = getActivity().getPreferences(getActivity().MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("ccc", String.valueOf(ccc));
        editor.apply();
    }

    @Override
    public void onResume(){
        super.onResume();
        SharedPreferences settings = getActivity().getPreferences(getActivity().MODE_PRIVATE);
        ccc = (Integer.parseInt(settings.getString("ccc", "0")));
        correctChangeCount.setText(ccc.toString());
    }


    public ChangeActions() {
    }

    public void incrementCorrectChangeCount(){
        ccc++;
        correctChangeCount.setText(String.valueOf(ccc));
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ccc = 0;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rv = inflater.inflate(R.layout.fragment_change_actions, container, false);
        Button startOver = (Button) rv.findViewById(R.id.button_startOver);
        Button newAmount = (Button) rv.findViewById(R.id.button_newAmount);
        correctChangeCount = (TextView) rv.findViewById(R.id.value_CorrectChangeCount);
        ma = (MainActivity) getActivity();
        startOver.setOnClickListener(this);
        newAmount.setOnClickListener(this);
        return rv;
    }

    @Override
    public void onClick(View view) {
        runButtonAction(view);
    }

    private void runButtonAction(View v) {
        switch (v.getId()) {
            case R.id.button_startOver:
                ma.cancelTimer();
                ma.startOver();
                break;
            case R.id.button_newAmount:
                ma.cancelTimer();
                ma.newAmount();
                break;

        }
    }

    public void zeroCorrectChangeCount() {
        ccc = 0;
        correctChangeCount.setText(String.valueOf(ccc));
    }
}
