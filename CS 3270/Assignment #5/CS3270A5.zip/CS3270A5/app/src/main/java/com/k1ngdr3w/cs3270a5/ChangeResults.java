package com.k1ngdr3w.cs3270a5;


import android.app.Fragment;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Random;
import java.util.concurrent.TimeUnit;


/**
 * A simple {@link Fragment} subclass.
 */
public class ChangeResults extends Fragment {
    private final DecimalFormat df2 = new DecimalFormat("###.##");
    private final NumberFormat format =
            NumberFormat.getCurrencyInstance(Locale.US);
    private TextView totalSoFar;
    private TextView remainingTime;
    private TextView changeToMake;
    private MainActivity ma;
    private MyCountDownTimer countDownTimer;
    private boolean timerHasFinished;
    Integer time;
    private double total = 0;
    private double changeAmount = 0;

    private long startTime = 15000;


    //Save Prefs and cancel timer
    @Override
    public void onPause() {
        super.onPause();
        SharedPreferences prefs = getActivity().getPreferences(getActivity().MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("changeToMake", String.valueOf(total));
        editor.putString("changeSoFar", String.valueOf(changeAmount));
//        editor.putInt("time", time);
        editor.apply();
        cancelTimer();
    }

    //Load prefs start timer
    @Override
    public void onResume() {
        super.onResume();
        SharedPreferences settings = getActivity().getPreferences(getActivity().MODE_PRIVATE);
        total = (Double.parseDouble((settings.getString("changeToMake", "0"))));
        changeAmount = (Double.parseDouble((settings.getString("changeSoFar", "0"))));
      //  startTime = settings.getInt("time", 15);
        totalSoFar.setText(String.valueOf(format.format(formatMoney(formatMoney(changeAmount)))));
        changeToMake.setText(String.valueOf(format.format(formatMoney(total))));
        countDownTimer.start();

    }

    public ChangeResults() {
        // Required empty public constructor
    }

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        long interval = 1000;
        countDownTimer = new MyCountDownTimer(startTime, interval);

    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rv = inflater.inflate(R.layout.fragment_change_results, container, false);
        ma = (MainActivity) getActivity();

        totalSoFar = (TextView) rv.findViewById(R.id.totalSoFar);
        changeToMake = (TextView) rv.findViewById(R.id.changeToMake);
        remainingTime = (TextView) rv.findViewById(R.id.timeRemaining);
        remainingTime.setText("15");
        return rv;
    }


    public void updateChangeAmount(double amount) {
        changeAmount = formatMoney(changeAmount + amount);
        totalSoFar.setText(String.valueOf(format.format(formatMoney(changeAmount))));
    }

    //Make the money look pretty
    private double formatMoney(double amount) {
        return Double.valueOf(df2.format(amount));
    }

    public void newAmount() {
        double rangeMin = 0;
        double rangeMax = 50;
        //double rangeMax = Double.parseDouble(sharedPrefs.getString("max", "50.00"));
        Random r = new Random();
        double randomValue = rangeMin + (rangeMax - rangeMin) * r.nextDouble();
        changeToMake.setText(String.valueOf(format.format(formatMoney(randomValue))));
        total = randomValue;
        countDownTimer.start();

    }

    //Update change to make amount
    public void newUserDefinedAmount(Double amount) {
        changeToMake.setText(String.valueOf(format.format(formatMoney(amount))));
        total = amount;
        countDownTimer.start();

    }

    //Reset
    public void startOver() {
        changeAmount = 0;
        totalSoFar.setText(String.valueOf(format.format(formatMoney(changeAmount))));
        countDownTimer.start();

    }

    public boolean isTimerFinished() {
        return timerHasFinished;
    }

    public void setTimerFinished(boolean boo) {
        timerHasFinished = boo;
    }

    public void cancelTimer() {
        countDownTimer.cancel();
        timerHasFinished = true;
    }

    public double getChangeToMake() {
        return total;
    }

    public double getTotalSoFar() {
        return changeAmount;
    }

    public void setChangeToMake(double amount) {
        changeAmount = amount;
        changeToMake.setText(String.valueOf(format.format(formatMoney(changeAmount))));
    }

    public void setTotalSoFar(double amount) {
        total = amount;
        totalSoFar.setText(String.valueOf(format.format(formatMoney(total))));
    }


    public class MyCountDownTimer extends CountDownTimer {
        public MyCountDownTimer(long startTime, long interval) {
            super(startTime, interval);
            timerHasFinished = false;
        }

        @Override
        public void onFinish() {
            timerHasFinished = true;
            remainingTime.setText("0");
            ma.createGameAlert("You should try again.", "You took too long.", "startOver");
            startTime = 15000;
        }

        @Override
        public void onTick(long millisUntilFinished) {
          //  time = Integer.parseInt(String.valueOf(TimeUnit.MILLISECONDS.toSeconds(startTime))) - Integer.parseInt(String.valueOf(TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished)));
            timerHasFinished = false;
            remainingTime.setText(String.valueOf(TimeUnit.MILLISECONDS.toSeconds(millisUntilFinished)));

        }

    }

}
