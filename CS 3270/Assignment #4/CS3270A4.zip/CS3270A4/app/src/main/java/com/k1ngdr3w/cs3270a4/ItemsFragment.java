package com.k1ngdr3w.cs3270a4;


import android.app.Fragment;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;


/**
 * A simple {@link Fragment} subclass.
 */
public class ItemsFragment extends Fragment {


    public ItemsFragment() {
        // Required empty public constructor
    }

    private View rootView;
    private EditText amount1;
    private EditText amount2;
    private EditText amount3;
    private EditText amount4;
    private MainActivity ma;
    private double taxRate;
    private double taxAmount;
    private double preTaxAmount;
    private double val1;
    private double val2;
    private double val3;
    private double val4;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public void onPause(){
        super.onPause();
        SharedPreferences prefs = getActivity().getPreferences(getActivity().MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("item1", getItemAmounts()[0]);
        editor.putString("item2", getItemAmounts()[1]);
        editor.putString("item3", getItemAmounts()[2]);
        editor.putString("item4", getItemAmounts()[3]);
        editor.apply();
    }

    @Override
    public void onResume(){
        super.onResume();
        SharedPreferences settings = getActivity().getPreferences(getActivity().MODE_PRIVATE);
        double[] items = new double[] {Double.parseDouble(settings.getString("item1", "0")), Double.parseDouble(settings.getString("item2", "0")), Double.parseDouble(settings.getString("item3", "0")), Double.parseDouble(settings.getString("item4", "0"))};
        setAmounts(items);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.items_fragment, container, false);
        ma = (MainActivity) getActivity();
        amount1 = (EditText) rootView.findViewById(R.id.amount1);
        amount2 = (EditText) rootView.findViewById(R.id.amount2);
        amount3 = (EditText) rootView.findViewById(R.id.amount3);
        amount4 = (EditText) rootView.findViewById(R.id.amount4);

        TextWatcher tw1 = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                val1 = (s.toString().length() > 0) ? Double.valueOf(s.toString()) : 0;
                val2 = (amount2.getText().toString().length() > 0) ? Double.valueOf(amount2.getText().toString()) : 0;
                val3 = (amount3.getText().toString().length() > 0) ? Double.valueOf(amount3.getText().toString()) : 0;
                val4 = (amount4.getText().toString().length() > 0) ? Double.valueOf(amount4.getText().toString()) : 0;
                ma.resetTaxAmount();
                taxRate = ma.getTaxPercentage();
                preTaxAmount = val1 + val2 + val3 + val4;
                taxAmount = preTaxAmount * taxRate;
                ma.updateTotal(taxAmount + preTaxAmount);
                ma.setTaxAmount(taxAmount);
            }
        };

        TextWatcher tw2 = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                val1 = (amount1.getText().toString().length() > 0) ? Double.valueOf(amount1.getText().toString()) : 0;
                val2 = (s.toString().length() > 0) ? Double.valueOf(s.toString()) : 0;
                val3 = (amount3.getText().toString().length() > 0) ? Double.valueOf(amount3.getText().toString()) : 0;
                val4 = (amount4.getText().toString().length() > 0) ? Double.valueOf(amount3.getText().toString()) : 0;
                ma.resetTaxAmount();
                taxRate = ma.getTaxPercentage();
                preTaxAmount = val1 + val2 + val3 + val4;
                taxAmount = preTaxAmount * taxRate;
                ma.updateTotal(taxAmount + preTaxAmount);
                ma.setTaxAmount(taxAmount);
            }
        };

        TextWatcher tw3 = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                val1 = (amount1.getText().toString().length() > 0) ? Double.valueOf(amount1.getText().toString()) : 0;
                val2 = (amount2.getText().toString().length() > 0) ? Double.valueOf(amount2.getText().toString()) : 0;
                val3 = (s.toString().length() > 0) ? Double.valueOf(s.toString()) : 0;
                val4 = (amount4.getText().toString().length() > 0) ? Double.valueOf(amount3.getText().toString()) : 0;
                ma.resetTaxAmount();
                taxRate = ma.getTaxPercentage();
                preTaxAmount = val1 + val2 + val3 + val4;
                taxAmount = preTaxAmount * taxRate;
                ma.updateTotal(taxAmount + preTaxAmount);
                ma.setTaxAmount(taxAmount);
            }
        };

        TextWatcher tw4 = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                val1 = (amount1.getText().toString().length() > 0) ? Double.valueOf(amount1.getText().toString()) : 0;
                val2 = (amount2.getText().toString().length() > 0) ? Double.valueOf(amount2.getText().toString()) : 0;
                val3 = (amount3.getText().toString().length() > 0) ? Double.valueOf(amount3.getText().toString()) : 0;
                val4 = (s.toString().length() > 0) ? Double.valueOf(s.toString()) : 0;
                ma.resetTaxAmount();
                taxRate = ma.getTaxPercentage();
                preTaxAmount = val1 + val2 + val3 + val4;
                taxAmount = preTaxAmount * taxRate;
                ma.updateTotal(taxAmount + preTaxAmount);
                ma.setTaxAmount(taxAmount);
            }
        };

        amount1.addTextChangedListener(tw1);
        amount2.addTextChangedListener(tw2);
        amount3.addTextChangedListener(tw3);
        amount4.addTextChangedListener(tw4);
        return rootView;

    }

    public double getTaxAmount() {
        return taxAmount;
    }

    public double getNonTaxAmount() {
        return preTaxAmount;
    }

    private String[] getItemAmounts() {
        return new String[]{ String.valueOf(val1), String.valueOf(val2), String.valueOf(val3), String.valueOf(val4)};

    }

    private void setAmounts(double[] amounts){
        val1 = amounts[0];
        val2 = amounts[1];
        val3 = amounts[2];
        val4 = amounts[3];
        amount1.setText(String.valueOf(val1));
        amount2.setText(String.valueOf(val2));
        amount3.setText(String.valueOf(val3));
        amount4.setText(String.valueOf(val4));
    }
}
