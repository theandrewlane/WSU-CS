package com.k1ngdr3w.cs3270a4;


import android.app.Fragment;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.SeekBar;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class TaxFragment extends Fragment {


    private View rootView;
    private MainActivity ma;
    private TextView taxRate;
    private TextView taxAmount;
    private SeekBar seekBar;
    private double decimalProgress;
    private double amountTax;
    private double amountTaxRate;
    private int globalProgress;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        decimalProgress = 0;
    }

    public TaxFragment() {
        // Required empty public constructor
    }

    @Override
    public void onPause(){
        super.onPause();
        SharedPreferences prefs = getActivity().getPreferences(getActivity().MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("taxAmount", String.valueOf(getTaxAmount()));
        editor.putString("taxRate", String.valueOf(getTaxRate()));
        editor.putInt("seekProgress", globalProgress);
        editor.apply();
    }

    @Override
    public void onResume(){
        super.onResume();
        SharedPreferences settings = getActivity().getPreferences(getActivity().MODE_PRIVATE);
        double[] tax = new double [] {Double.parseDouble(settings.getString("taxRate", "0")), Double.parseDouble(settings.getString("taxAmount", "0"))};
        setTaxAmount(tax[1]);
        setTaxRate(tax[0]);
     //   seekBar.setProgress(settings.getInt("seekProgress", 0));
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.tax_fragment, container, false);
        seekBar = (SeekBar) rootView.findViewById(R.id.seekBar);
        taxRate = (TextView) rootView.findViewById(R.id.taxRate);
        taxAmount = (TextView) rootView.findViewById(R.id.taxAmount);
        taxRate.setText("0.00%");
        ma = (MainActivity) getActivity();

        seekBar.setOnSeekBarChangeListener(
                new SeekBar.OnSeekBarChangeListener() {
                    @Override
                    public void onProgressChanged(SeekBar seekBar, int progressValue, boolean fromUser) {
                        globalProgress = progressValue;
                        //Update tax amount
                        //Send updated tax amount to main activity => main activity then updates totalsFrag
                        decimalProgress = (double) progressValue / 4.0;
                        amountTaxRate = decimalProgress / 1000;
                        amountTax = ma.getNewTaxAmount();
                        taxRate.setText(String.valueOf(decimalProgress / 10) + "%");
                        taxAmount.setText(String.valueOf(amountTax) + "%");
                        ma.updateTotalWithTax(amountTaxRate);

                    }

                    @Override
                    public void onStartTrackingTouch(SeekBar seekBar) {

                    }

                    @Override
                    public void onStopTrackingTouch(SeekBar seekBar) {
                        // Display the value in textview
                        //  taxRate.setText(progress + "/" + seekBar.getMax());
                    }
                });
        return rootView;
    }


    public double getTaxRate() {
        return amountTaxRate;
    }

    public void setTaxAmount(double amount) {
        amountTax = amount;
        taxAmount.setText(String.valueOf("$" + String.format("%.2f", amountTax)));
    }

    private double getTaxAmount(){
        return amountTax;
    }

    private void setTaxRate(double rate){
        amountTaxRate = rate;
        taxRate.setText(amountTaxRate + "%");

    }

    public void devSetTaxAmount() {
        amountTax = 0;
    }
}

