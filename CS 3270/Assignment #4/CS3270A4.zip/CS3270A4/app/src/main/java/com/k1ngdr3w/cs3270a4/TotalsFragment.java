package com.k1ngdr3w.cs3270a4;


import android.app.Fragment;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.text.NumberFormat;
import java.util.Locale;


/**
 * A simple {@link Fragment} subclass.
 */
public class TotalsFragment extends Fragment {

    private View rootView;
    private TextView total;
    private MainActivity ma;
    private double taxAmount;
    private double totalAmount;
    private final NumberFormat format =
            NumberFormat.getCurrencyInstance(Locale.US);

    public TotalsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onPause(){
        super.onPause();
        SharedPreferences prefs = getActivity().getPreferences(getActivity().MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("totalAmount", String.valueOf(getTotalAmount()));
        editor.apply();
    }

    @Override
    public void onResume(){
        super.onResume();
        SharedPreferences settings = getActivity().getPreferences(getActivity().MODE_PRIVATE);
        setTotalAmount(Double.parseDouble(settings.getString("totalAmount", "0.00")));
        updateAmount(Double.parseDouble(settings.getString("totalAmount", "0.00")));
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.totals_fragement, container, false);
        total = (TextView) rootView.findViewById(R.id.totalAmount);
        total.setText("$0.00");
        ma = (MainActivity) getActivity();
        return rootView;
    }

    public void updateAmount(double amount) {
        total.setText(String.valueOf(format.format(amount)));
    }

    public void updateAmountWithTax(double amount) {
        totalAmount = ma.getNonTaxTotal();
        if (totalAmount > 0) {
            taxAmount = amount;
            ma.setTaxAmount(totalAmount * taxAmount);
            totalAmount = (totalAmount * taxAmount) + totalAmount;
            total.setText(String.valueOf(format.format(totalAmount)));
        }
    }

    private double getTotalAmount(){
        return totalAmount;
    }

    private void setTotalAmount(double amount){
        totalAmount = amount;
    }
}
