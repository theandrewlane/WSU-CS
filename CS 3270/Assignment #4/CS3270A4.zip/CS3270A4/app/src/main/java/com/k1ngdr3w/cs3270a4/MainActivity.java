package com.k1ngdr3w.cs3270a4;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TaxFragment taxFragment;
    private ItemsFragment itemsFragment;
    private TotalsFragment totalsFragment;
    // public static final String PREFS_NAME = "MyPrefsFile";


 /*   @Override
    protected void onPause() {
        super.onPause();
        getFragmentManager().findFragmentByTag("itemsFragment").setRetainInstance(true);
        getFragmentManager().findFragmentByTag("taxFragment").setRetainInstance(true);
        getFragmentManager().findFragmentByTag("totalsFragment").setRetainInstance(true);
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        SharedPreferences.Editor editor = settings.edit();
        editor.putString("item1", itemsFragment.getItemAmounts()[0]);
        editor.putString("item2", itemsFragment.getItemAmounts()[1]);
        editor.putString("item3", itemsFragment.getItemAmounts()[2]);
        editor.putString("item4", itemsFragment.getItemAmounts()[3]);
        editor.putString("taxAmount", String.valueOf(taxFragment.getTaxAmount()));
        editor.putString("taxRate", String.valueOf(taxFragment.getTaxRate()));
        editor.putString("totalAmount", String.valueOf(totalsFragment.getTotalAmount()));
        editor.commit();
    }*/

/*    @Override
    protected void onResume() {
        super.onResume();
        getFragmentManager().findFragmentByTag("itemsFragment").getRetainInstance();
        getFragmentManager().findFragmentByTag("taxFragment").getRetainInstance();
        getFragmentManager().findFragmentByTag("totalsFragment").getRetainInstance();
        SharedPreferences settings = getSharedPreferences(PREFS_NAME, 0);
        double[] items = new double[] {Double.parseDouble(settings.getString("item1", null)), Double.parseDouble(settings.getString("item2", null)), Double.parseDouble(settings.getString("item3", null)), Double.parseDouble(settings.getString("item4", null))};
        double[] tax = new double [] {Double.parseDouble(settings.getString("taxRate", null)), Double.parseDouble(settings.getString("taxAmount", null))};
        double total = Double.parseDouble(settings.getString("totalAmount", null));
        itemsFragment.setAmounts(items);
        taxFragment.setTaxAmount(tax[1]);
        taxFragment.setTaxRate(tax[0]);
        totalsFragment.setTotalAmount(total);
    }*/


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        itemsFragment = (ItemsFragment)
                getFragmentManager().findFragmentByTag("itemsFragment");

        taxFragment = (TaxFragment)
                getFragmentManager().findFragmentByTag("taxFragment");

        totalsFragment = (TotalsFragment)
                getFragmentManager().findFragmentByTag("totalsFragment");


    }

    public double getNonTaxTotal() {
        return itemsFragment.getNonTaxAmount();
    }

    public void updateTotalWithTax(double tax) {
        totalsFragment.updateAmountWithTax(tax);
    }

    public void setTaxAmount(double amount) {
        taxFragment.setTaxAmount(amount);
    }

    public void resetTaxAmount() {
        taxFragment.devSetTaxAmount();
    }

    public void updateTotal(double total) {
        totalsFragment.updateAmount(total);
    }

    public double getTaxPercentage() {
        return taxFragment.getTaxRate();
    }

    public double getNewTaxAmount() {
        return itemsFragment.getTaxAmount();
    }
}
