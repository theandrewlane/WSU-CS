package com.k1ngdr3w.cs3270a7;


import android.app.Activity;
import android.app.ListFragment;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;


/**
 * Created by k1ngdr3w on 6/1/16.
 */
public class CourseListFragment extends ListFragment {
    public String KEY_ROWID = "_id";
    public String KEY_COURSEID = "id";
    public String KEY_COURSECODE = "course_code";
    public String KEY_NAME = "name";
    public String KEY_STARTAT = "start_at";
    public String KEY_ENDAT = "end_at";
    DatabaseHelper dbHelper;
    private CursorAdapter cursorAdapter;
    private CLF_Listener clf_listener;
    ListView clf_View;
    MainActivity ma;
    View rv;

    // callback methods implemented by MainActivity
    public interface CLF_Listener {
        public void onAdd();

        // called when user selects a course
        public void onSelect(long rowID);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        clf_listener = (CLF_Listener) activity;
    }


    @Override
    public void onDetach() {
        super.onDetach();
        clf_listener = null;
    }

    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rv = inflater.inflate(R.layout.fragment_course_list, container, false);
        return super.onCreateView(inflater, container, savedInstanceState);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setRetainInstance(true); // save fragment across config changes
        ma = (MainActivity) getActivity();

        ma.hideAddButton(false);
        ma.hideSaveButton(true);
        // FANCY setEmptyText("Click the add button to insert a course!");
        clf_View = getListView();
        clf_View.setOnItemClickListener(viewCourseListener);
        int[] resultView = new int[]{android.R.id.text1};
        String[] nameColumn = new String[]{KEY_NAME};

        cursorAdapter = new SimpleCursorAdapter(getActivity(),
                android.R.layout.simple_list_item_1, null, nameColumn, resultView, 0);
        setListAdapter(cursorAdapter);

        //clf_View.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
//        String[] col = new String[]{KEY_NAME};
//        int[] l_view = new int[]{android.R.id.text1};
//        simpleCursorAdapter = new SimpleCursorAdapter(getActivity(),
//                android.R.layout.simple_list_item_1, null, col, l_view, 0);
//        setListAdapter(simpleCursorAdapter);
        // new GetCoursesFromDB().execute("");
    }

    OnItemClickListener viewCourseListener = new OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view,
                                int position, long id) {
            Log.w("LIST VIEW1", "Long id =" + id + "position:" + position);

            clf_listener.onSelect(id); // pass selection to MainActivity
        }

    };

    @Override
    public void onResume() {
        super.onResume();
        new GetCoursesFromDB().execute("");
    }

    private class GetCoursesFromDB extends AsyncTask<String, Integer, Cursor> {
        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());

        @Override
        protected Cursor doInBackground(String... params) {
            dbHelper.open();
            Cursor cursor = dbHelper.getAllCourses();
            return cursor;
        }

        //TODO implemetn cjamge cursor
        @Override
        protected void onPostExecute(Cursor cursor) {

            cursorAdapter.changeCursor(cursor);
            dbHelper.close();
        }
    }

    //Kill the cursor
    public void onStop() {
        Cursor cursor = cursorAdapter.getCursor();
        cursorAdapter.swapCursor(null);
        if (cursor != null) {
            cursor.close();
        }
        super.onStop();
    }

    public void refreshCourses() {
        new GetCoursesFromDB().execute("");
    }
/*


    ma=(MainActivity)

    getActivity();

    View view = inflater.inflate(R.layout.fragment_course_list, container, false);
    dbHelper=new

    DatabaseHelper(getActivity(),DatabaseHelper

    .DATABASE_TABLE,null,1);
    Cursor cursor = dbHelper.getAllCourses();
    String[] columns = new String[]{dbHelper.KEY_NAME};
    int[] views = new int[]{android.R.id.text1};
    SimpleCursorAdapter adapter =
            new SimpleCursorAdapter(getActivity(), android.R.layout.simple_list_item_1, cursor, columns, views, CursorAdapter.FLAG_REGISTER_CONTENT_OBSERVER);

    setListAdapter(adapter);

    return super.

    onCreateView(inflater, container, savedInstanceState);
*/

}
