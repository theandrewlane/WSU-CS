package com.k1ngdr3w.cs3270a7;


import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.content.DialogInterface;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class CourseViewFragment extends Fragment {

    public String KEY_ROWID = "_id";
    public String KEY_COURSEID = "id";
    public String KEY_COURSECODE = "course_code";
    public String KEY_NAME = "name";
    public String KEY_STARTAT = "start_at";
    public String KEY_ENDAT = "end_at";
    private CVF_Listener cvf_listener;

    // private EditText edit_id, edit_name, edit_courseCode, edit_startAt, edit_endAt;
    private TextView tv_id, tv_name, tv_courseCode, tv_startAt, tv_endAt;
    int courseID, courseCode, name, startAt, endAt;
    MainActivity ma;
    private View rv;
    private long rowID;

    public interface CVF_Listener {
        // called when a course is deleted
        void onDelete();

        // called to pass Bundle of course's info for editing
        void onEdit(Bundle arguments);
    }


    public CourseViewFragment() {
        // Required empty public constructor
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        cvf_listener = (CVF_Listener) activity;
    }

    @Override
    public void onDetach() {
        super.onDetach();
        cvf_listener = null;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            //EDIT SELECTION
            case R.id.action_Edit:
                Bundle arguments = new Bundle();
                Log.w("CS3287 ____-----______!", "db helper getOneCourse called once for the ID: " + rowID);
                arguments.putLong(KEY_ROWID, rowID);
                arguments.putCharSequence(KEY_COURSEID, tv_id.getText());
                arguments.putCharSequence(KEY_NAME, tv_name.getText());
                arguments.putCharSequence(KEY_COURSECODE, tv_courseCode.getText());
                arguments.putCharSequence(KEY_STARTAT, tv_startAt.getText());
                arguments.putCharSequence(KEY_ENDAT, tv_endAt.getText());
                cvf_listener.onEdit(arguments);
                return true;
            //DELETE THAT SHIZ
            case R.id.action_delete:
                deleteCourse();
                return true;
        }

        return super.onOptionsItemSelected(item);
    }

    //TODO FIND SOMETHING MROE ELEGANT
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        MenuItem item3 = menu.findItem(R.id.action_delete);
        MenuItem item = menu.findItem(R.id.action_Edit);
        item3.setVisible(true);
        item.setVisible(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
        inflater.inflate(R.menu.menuicons, menu);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {


        super.onCreateView(inflater, container, savedInstanceState);
        setHasOptionsMenu(true);
        ma = (MainActivity) getActivity();

        ma.hideAddButton(true);
        ma.hideSaveButton(true);

        if (savedInstanceState != null) {

            rowID = savedInstanceState.getLong(KEY_ROWID);
        }
        else {
            Bundle arguments = getArguments();
            if (arguments != null) {
                rowID = arguments.getLong("_id");
            }
        }

        rv = inflater.inflate(R.layout.fragment_course_view, container, false);
        tv_id = (TextView) rv.findViewById(R.id.viewID);
        tv_name = (TextView) rv.findViewById(R.id.viewName);
        tv_courseCode = (TextView) rv.findViewById(R.id.viewCourseCode);
        tv_startAt = (TextView) rv.findViewById(R.id.viewStartAt);
        tv_endAt = (TextView) rv.findViewById(R.id.viewEditAt);
        //  new GetCourseFromDB().execute(rowID);
        return rv;

    }

    // called when the DetailsFragment resumes, which is always
    @Override
    public void onResume() {
        super.onResume();
        Log.d("_____-------!", "In onres");

        Bundle arguments = getArguments();
        //Grab the ID
        rowID = arguments.getLong("_id");
        new GetCourseFromDB().execute(rowID);
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        //SAve tje row
        super.onSaveInstanceState(outState);
        outState.putLong(KEY_ROWID, rowID);
    }

//Throw popup warning
    private void deleteCourse() {
        DeleteCourseDialoge.show(getFragmentManager(), "DELETE");
    }

    private class GetCourseFromDB extends AsyncTask<Long, Object, Cursor> {
        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());

        @Override
        protected Cursor doInBackground(Long... params) {
            dbHelper.open();
            Log.d("_____-------!", "In on TASK");

            Cursor cursor = dbHelper.getOneCourse(params[0]);
            return cursor;
        }

        // use cursor returned from above
        @Override
        protected void onPostExecute(Cursor cursor) {
            super.onPostExecute(cursor);
            if (cursor != null && cursor.moveToFirst()) {
                courseID = cursor.getColumnIndex(KEY_COURSEID);
                name = cursor.getColumnIndex(KEY_NAME);
                courseCode = cursor.getColumnIndex(KEY_COURSECODE);
                startAt = cursor.getColumnIndex(KEY_STARTAT);
                endAt = cursor.getColumnIndex(KEY_ENDAT);
                tv_id.setText(cursor.getString(courseID));
                tv_name.setText(cursor.getString(name));
                tv_courseCode.setText(cursor.getString(courseCode));
                tv_startAt.setText(cursor.getString(startAt));
                tv_endAt.setText(cursor.getString(endAt));
                cursor.close();
                dbHelper.close();
            }
        }
    }

    private final DialogFragment DeleteCourseDialoge = new DialogFragment() {
        @Override
        public Dialog onCreateDialog(Bundle bundle) {

            AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            builder.setMessage("This will permanently delete this course");
            builder.setTitle("Are you sure?");
            builder.setPositiveButton("DELETE",
                    new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(
                                DialogInterface dialog, int button) {
                            final DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
                            AsyncTask<Long, Object, Object> deleteCourse =
                                    new AsyncTask<Long, Object, Object>() {
                                        @Override
                                        protected Object doInBackground(Long... params) {
                                            dbHelper.open();
                                            return dbHelper.deleteRow(params[0]);
                                        }

                                        @Override
                                        protected void onPostExecute(Object boo) {
                                            super.onPostExecute(boo);
                                            cvf_listener.onDelete();
                                            dbHelper.close();

                                        }
                                    };
                            deleteCourse.execute(rowID);

                        }
                    }
            );

            builder.setNegativeButton("CANCEL", null);
            return builder.create(); // return the AlertDialog
        }
    };
}
