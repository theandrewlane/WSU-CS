package com.k1ngdr3w.cs3270a7;


import android.app.ListFragment;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CursorAdapter;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.text.SimpleDateFormat;

import javax.net.ssl.HttpsURLConnection;

/**
 * Created by k1ngdr3w on 6/1/16.
 */
public class AssignmentListFragment extends ListFragment {
    public String KEY_ROWID = "_id";
    public String KEY_COURSEID = "id";
    public String KEY_COURSECODE = "course_code";
    public String KEY_NAME = "name";
    public String KEY_STARTAT = "start_at";
    public String KEY_ENDAT = "end_at";
    DatabaseHelper dbHelper;
    protected ArrayAdapter<String> assAdapter;


    private CursorAdapter cursorAdapter;
    ListView alf_View;
    View rv;


    MainActivity ma;
    Long rowID;

    public AssignmentListFragment() {
        // Required empty public constructor
    }

    // callback methods implemented by MainActivity

    @Override
    public void onSaveInstanceState(Bundle outState) {
        //SAve tje row
        super.onSaveInstanceState(outState);
        outState.putLong(KEY_ROWID, rowID);
    }

    //TODO FIND SOMETHING MROE ELEGANT
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        MenuItem item3 = menu.findItem(R.id.action_delete);
        MenuItem item2 = menu.findItem(R.id.action_importCourses);
        MenuItem item = menu.findItem(R.id.action_Edit);
        MenuItem item4 = menu.findItem(R.id.action_BackToList);
        item3.setVisible(false);
        item2.setVisible(false);
        item.setVisible(false);
        item4.setVisible(true);
    }


    @Override
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setRetainInstance(true); // save fragment across config changes
        ma = (MainActivity) getActivity();
        ma.hideAddButton(true);
        ma.hideSaveButton(true);
         setEmptyText("Loading assignments for this course...");
        alf_View = getListView();
        assAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1);
        setListAdapter(assAdapter);
    }


    @Override
    public void onResume() {
        super.onResume();
        Bundle arguments = getArguments();
        //Grab the ID
        rowID = arguments.getLong("_id");
        new GetCourseIDFromDB().execute(rowID);

    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
        inflater.inflate(R.menu.menuicons, menu);
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rv = inflater.inflate(R.layout.fragment_assignment_list, container, false);

        if (savedInstanceState != null) {

            rowID = savedInstanceState.getLong(KEY_ROWID);
        } else {
            Bundle arguments = getArguments();
            if (arguments != null) {
                rowID = arguments.getLong("_id");
            }
        }

        return super.onCreateView(inflater, container, savedInstanceState);
    }


    private class GetCourseIDFromDB extends AsyncTask<Long, Object, Cursor> {
        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());

        @Override
        protected Cursor doInBackground(Long... params) {
            dbHelper.open();
            Log.d("_____-------!", "In on TASK");

            Cursor cursor = dbHelper.getOneCourse(params[0]);
            return cursor;
        }

        // use cursor returned from above
        @Override
        protected void onPostExecute(Cursor cursor) {
            super.onPostExecute(cursor);
            if (cursor != null && cursor.moveToFirst()) {
                String courseID = cursor.getString(cursor.getColumnIndex(KEY_COURSEID));
                cursor.close();
                dbHelper.close();
                new getCourseAssignments().execute(courseID);
            }
        }
    }

    //Get the course ID, then pass it in to the Canvas API call task
    public class getCourseAssignments extends AsyncTask<String, Integer, String> {
        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
        String rawJSON = "";

        @Override
        protected String doInBackground(String... params) {
            try {
                URL url = new URL("https://weber.instructure.com/api/v1/courses/" + params[0] + "/assignments");
                Log.w("URL HERE", url.toString());
                HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Authorization", "Bearer " + ma.AUTH_TOKEN);
                conn.connect();
                int status = conn.getResponseCode();
                switch (status) {
                    case 404:
                        dbHelper.close();
                        return null;
                    case 200:
                    case 201:
                        BufferedReader br =
                                new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        rawJSON = br.readLine();
                        Log.d("URL STUFF", rawJSON);

                }
            } catch (MalformedURLException e) {
                Log.d("test", e.getMessage());
                dbHelper.close();

            } catch (ProtocolException e) {
                e.printStackTrace();
                dbHelper.close();

            } catch (IOException e) {
                e.printStackTrace();
                dbHelper.close();

            }
            return rawJSON;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            assAdapter.clear();

            try {
                AssignmentObjects.Assignment[] assignments = jsonParse(result);
                for (AssignmentObjects.Assignment assignment : assignments) {
                    assAdapter.add("Assignment Name: " + assignment.name + "\nPoints Possible: " + assignment.points_possible + "\nDue By: " + assignment.due_at);
                }
            } catch (Exception e) {

            }
        }
    }

    private AssignmentObjects.Assignment[] jsonParse(String rawJson) {
        GsonBuilder gsonb = new GsonBuilder();
        Gson gson = gsonb.create();
        AssignmentObjects.Assignment[] assignments = null;

        try {
            assignments = gson.fromJson(rawJson, AssignmentObjects.Assignment[].class);
        } catch (Exception e) {

        }
        return assignments;
    }


}

