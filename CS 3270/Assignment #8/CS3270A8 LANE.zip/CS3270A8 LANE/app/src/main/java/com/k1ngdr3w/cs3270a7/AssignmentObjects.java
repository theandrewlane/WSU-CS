package com.k1ngdr3w.cs3270a7;


/**
 * Created by k1ngdr3w on 6/8/15.
 */
public class AssignmentObjects {

    protected class Assignment {
        protected String id;
        protected String description;
        protected String due_at;

        protected String points_possible;

        protected String name;

    }

}
