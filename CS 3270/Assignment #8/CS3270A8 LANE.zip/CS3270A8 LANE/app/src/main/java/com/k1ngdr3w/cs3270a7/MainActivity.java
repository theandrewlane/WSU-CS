package com.k1ngdr3w.cs3270a7;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;


/**
 * Created by k1ngdr3w on 6/1/16.
 */
public class MainActivity extends AppCompatActivity implements CourseListFragment.CLF_Listener, CourseEditFragment.CEF_Listener, CourseViewFragment.CVF_Listener {

  /* ------------ AUTH TOKEN HERE!!! ----------------*/
    public static String AUTH_TOKEN = "AUTH TOKEN HERE";
  /* ------------ AUTH TOKEN HERE!!! ----------------*/


    CourseEditFragment CEF;
    CourseListFragment CLF;
    CourseViewFragment CVF;
    AssignmentListFragment ALF;

    public String KEY_ROWID = "_id";
    public String KEY_COURSEID = "id";
    public String KEY_COURSECODE = "course_code";
    public String KEY_NAME = "name";
    public String KEY_STARTAT = "start_at";
    public String KEY_ENDAT = "end_at";

    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //Request keybaord
        InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
        //This has already been created so GTFO
        if (savedInstanceState != null) {
            return;
        }

        if (findViewById(R.id.mainLayout) != null) {
            Log.d("MAIN ACT LOGGING GOO!", "Arguments for CVF: " + findViewById(R.id.mainLayout));
            CLF = new CourseListFragment();
            FragmentTransaction transaction = getFragmentManager().beginTransaction();
            transaction.add(R.id.mainLayout, CLF);
            transaction.commit();
        }
    }

    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        menu.clear();
        inflater.inflate(R.menu.menuicons, menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menuicons, menu);

            MenuItem item3 = menu.findItem(R.id.action_delete);
            MenuItem item2 = menu.findItem(R.id.action_importCourses);
            MenuItem item = menu.findItem(R.id.action_Edit);
            MenuItem item4 = menu.findItem(R.id.action_BackToList);
            item3.setVisible(false);
            item2.setVisible(true);
            item.setVisible(false);
            item4.setVisible(false);
        // return true so that the menu pop up is opened
        return true;
    }

    @Override
    protected void onResume() {
        super.onResume();
       // deleteAll();
//        CLF.refreshCourses();


    }


    public void showListFragment() {
        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.hide(CVF);
        fragmentTransaction.hide(CEF);
        fragmentTransaction.commit();

    }

    public void showEditFragment() {
        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.hide(CVF);
        fragmentTransaction.hide(CLF);
        fragmentTransaction.commit();

    }

    public void showViewFragment() {
        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.hide(CLF);
        fragmentTransaction.hide(CEF);
        fragmentTransaction.commit();
    }


    //Called after a new course has been updated/created, pops back to CLV
    @Override
    public void onComplete(long rowID) {
        hideSaveButton(true);
        hideAddButton(false);
        getFragmentManager().popBackStack();
        getFragmentManager().popBackStack();
        CLF.refreshCourses();

    }


    @Override
    public void onAdd() {
        hideSaveButton(false);
        hideAddButton(true);
        CEF = new CourseEditFragment();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.mainLayout, CEF);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();

    }

    //When user selects item on listview, this should hide the mainlayout and show the CVF
    @Override
    public void onSelect(long rowID) {
        hideSaveButton(true);
        hideAddButton(true);
        CVF = new CourseViewFragment();
        Bundle arguments = new Bundle();
        arguments.putLong(KEY_ROWID, rowID);
        CVF.setArguments(arguments);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.mainLayout, CVF);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    //calls the assignments api and populates LV
    @Override
    public void onLongSelect(long rowID) {
        hideSaveButton(true);
        hideAddButton(true);

        ALF = new AssignmentListFragment();
        Bundle arguments = new Bundle();
        arguments.putLong(KEY_ROWID, rowID  );
        ALF.setArguments(arguments);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.mainLayout, ALF);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();
    }

    public void deleteAll(){
        CLF.deleteAll();

    }

    //When user confirms delete
    @Override
    public void onDelete() {
        getFragmentManager().popBackStack();
        getFragmentManager().popBackStack();
        hideAddButton(false);
        hideSaveButton(true);
        CLF.refreshCourses();
    }

    //When user edits the course
    @Override
    public void onEdit(Bundle arguments) {
        hideSaveButton(false);
        hideAddButton(true);
        CLF.refreshCourses();

        CEF = new CourseEditFragment();
        CEF.setArguments(arguments);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.mainLayout, CEF);
        fragmentTransaction.addToBackStack(null);
        fragmentTransaction.commit();

    }

    @Override
    public void onImport() {

        CLF.getCourses();
    }


    public void onClick_AddNewCourse(View view) {

        onAdd();
    }

    public void onClick_SaveCourse(View view) {

        boolean saveSuccess;
        saveSuccess = CEF.runSave();
        if (saveSuccess) {
            hideSaveButton(true);
            hideAddButton(false);
        }
        // CLF.refreshCourses();

    }

    public void hideAddButton(boolean hide) {
        View b = findViewById(R.id.addButton);
        if (b != null && hide) {
            b.setVisibility(View.INVISIBLE);
        }
        if (b != null && !hide) {
            b.setVisibility(View.VISIBLE);
        }
    }

    public void hideSaveButton(boolean hide) {
        View b = findViewById(R.id.saveButton);
        if (b != null && hide) {
            b.setVisibility(View.INVISIBLE);
        }
        if (b != null && !hide) {
            b.setVisibility(View.VISIBLE);
        }
    }

    //Defined in menu xml, executed when import button is clicked.
    public void importCanvasCourses(MenuItem item) {
        CLF.getCourses();
    }

    public void goBackToListView(MenuItem item) {
        getFragmentManager().popBackStack();
        getFragmentManager().popBackStack();
        hideAddButton(false);
        hideSaveButton(true);
        CLF.refreshCourses();
    }
}

