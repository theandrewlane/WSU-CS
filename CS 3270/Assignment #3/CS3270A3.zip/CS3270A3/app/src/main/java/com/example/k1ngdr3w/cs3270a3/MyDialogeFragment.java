package com.example.k1ngdr3w.cs3270a3;


import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.support.v4.app.Fragment;


/**
 * A simple {@link Fragment} subclass.
 */
public class MyDialogeFragment extends DialogFragment {

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(getActivity());
        alertDialogBuilder.setTitle("Play Again?");
        alertDialogBuilder.setMessage("Do you want to start over?");
        //null should be your on click listener
        alertDialogBuilder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                MainActivity ma = (MainActivity) getActivity();
                ma.reset();
                dialog.dismiss();
            }
        });
        alertDialogBuilder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
                AlertDialog.Builder alertDialogBuilder2 = new AlertDialog.Builder(getActivity());
                alertDialogBuilder2.setTitle("Bye");
                alertDialogBuilder2.setMessage("Thanks for playing!");
                alertDialogBuilder2.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                        System.exit(0);
                        getActivity().finish();
                    }
                });
                alertDialogBuilder2.show();
            }
        });
        return alertDialogBuilder.create();
    }
}

