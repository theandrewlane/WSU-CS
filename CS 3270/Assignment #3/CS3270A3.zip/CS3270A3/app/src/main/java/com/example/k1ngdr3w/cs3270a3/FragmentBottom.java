package com.example.k1ngdr3w.cs3270a3;


import android.annotation.SuppressLint;
import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


/**
 * A simple {@link Fragment} subclass.
 */
public class FragmentBottom extends Fragment {


    public FragmentBottom() {
        // Required empty public constructor
    }
View rootView;


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_bottom, container, false);
    }

    @SuppressLint("SetTextI18n")
    public void updateScore(Integer player, Integer score){

        TextView meScore = (TextView)getActivity().findViewById(R.id.bottomMeScore);
        TextView phoneScore = (TextView)getActivity().findViewById(R.id.bottomPhoneScore);
        if(player == 1)   meScore.setText(score.toString());
        if(player == -1) phoneScore.setText(score.toString());

    }

    public void resetScore(){

        TextView meScore = (TextView)getActivity().findViewById(R.id.bottomMeScore);
        TextView phoneScore = (TextView)getActivity().findViewById(R.id.bottomPhoneScore);
        meScore.setText("0");
        phoneScore.setText("0");
    }

}
