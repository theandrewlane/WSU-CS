package com.example.k1ngdr3w.cs3270a3;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.Toast;

public class MainActivity extends Activity {

    Integer meWins =0, phoneWins = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }

    public void reset(){
        FragmentBottom fb = (FragmentBottom) getFragmentManager().findFragmentByTag("fb");
        TopFragment tf = (TopFragment) getFragmentManager().findFragmentByTag("ft");
        meWins =0;
        phoneWins = 0;
        fb.resetScore();
        tf.reset();
    }

    public void showToaster(String player){
        Toast.makeText(this, player + " only needs one more win!",
                Toast.LENGTH_LONG).show();
    }

    public void kill(){

        finish();
    }

    public void startGame(Integer winner) {
        FragmentBottom fb = (FragmentBottom) getFragmentManager().findFragmentByTag("fb");
        MyDialogeFragment mdf = new MyDialogeFragment();
        mdf.setCancelable(false);
        if(winner == 1){
            meWins++;
            fb.updateScore(1, meWins);

        }
        if(winner == -1) {
            phoneWins++;
            fb.updateScore(-1, phoneWins);
        }
        if(meWins == 4){
            showToaster("The Player");
        }

        if(phoneWins == 4){
            showToaster("The Phone");

        }

        if(meWins == 5){
            mdf.show(getFragmentManager(), "gameOver?");

        }

        if(phoneWins == 5){
            mdf.show(getFragmentManager(), "gameOver?");

        }
    }
}
