package com.example.k1ngdr3w.cs3270a3;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;


/**
 * A simple {@link Fragment} subclass.
 */
public class TopFragment extends Fragment {


    View rootView;

    public TopFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_top, container, false);
        Button btnPlay = (Button) rootView.findViewById(R.id.buttonPlay);
        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] options = getOptions();
                Integer winner = getWinner(options[0], options[1]);
                MainActivity ma = (MainActivity) getActivity();
                ma.startGame(winner);
            }
        });

        return rootView;
    }

    public void reset(){
        TextView tv1 = (TextView) rootView.findViewById(R.id.meChoice);
        TextView tv2 = (TextView) rootView.findViewById(R.id.phoneChoice);
        TextView winnerText = (TextView) rootView.findViewById(R.id.topWinner);
        tv1.setText("____________");
        tv2.setText("____________");
        winnerText.setText("");
    }

    public String[] getOptions() {
        String[] options = {"Rock", "Paper", "Scissors"};
        int op1 = new Random().nextInt(options.length);
        int op2 = new Random().nextInt(options.length);
        TextView tv1 = (TextView) rootView.findViewById(R.id.meChoice);
        TextView tv2 = (TextView) rootView.findViewById(R.id.phoneChoice);
        tv1.setText(options[op1]);
        tv2.setText(options[op2]);
        return new String[]{options[op1], options[op2]};
    }

    //If i lose return -1 if i win return 1 if i tie return 0
    public int getWinner(String phoneRes, String meRes) {
        TextView winnerText = (TextView) rootView.findViewById(R.id.topWinner);

        if (phoneRes.equals("Rock")) {
            if (meRes.equals("Paper")) {
                winnerText.setText("You win");
                return 1;
            }
            if (meRes.equals("Scissors")) {
                winnerText.setText("The Phone wins");
                return -1;
            }
        }

        if (phoneRes.equals("Paper")) {
            if (meRes.equals("Scissors")) {
                winnerText.setText("You win");
                return 1;
            }

            if (meRes.equals("Rock")) {
                winnerText.setText("The Phone wins");
                return -1;
            }
        }

        if (phoneRes.equals("Scissors")) {
            if (meRes.equals("Paper")) {
                winnerText.setText("The Phone wins");
                return -1;
            }

            if (meRes.equals("Rock")) {
                winnerText.setText("You win");
                return 1;
            }
        }

        winnerText.setText("Tie!");
        return 0;
    }
}
