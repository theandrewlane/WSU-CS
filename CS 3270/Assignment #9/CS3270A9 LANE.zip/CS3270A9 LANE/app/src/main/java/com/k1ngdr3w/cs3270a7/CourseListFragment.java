package com.k1ngdr3w.cs3270a7;


import android.app.Activity;
import android.app.ListFragment;
import android.content.res.Configuration;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemLongClickListener;
import android.widget.CursorAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;

import javax.net.ssl.HttpsURLConnection;


/**
 * Created by k1ngdr3w on 6/1/16.
 */
public class CourseListFragment extends ListFragment {
    public String KEY_ROWID = "_id";
    public String KEY_COURSEID = "id";
    public String KEY_COURSECODE = "course_code";
    private final String KEY_NAME = "name";
    public String KEY_STARTAT = "start_at";
    public String KEY_ENDAT = "end_at";
    DatabaseHelper dbHelper;
    private CursorAdapter cursorAdapter;
    private CLF_Listener clf_listener;

    private ListView clf_View;
    private MainActivity ma;
    private View rv;


    // callback methods implemented by MainActivity
    public interface CLF_Listener {
        void onAdd();

        // called when user selects a course
        void onSelect(long rowID);

        void onLongSelect(long rowID);
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        clf_listener = (CLF_Listener) activity;
    }


    @Override
    public void onDetach() {
        super.onDetach();
        clf_listener = null;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        menu.clear();
        inflater.inflate(R.menu.menuicons, menu);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        rv = inflater.inflate(R.layout.fragment_course_list, container, false);


        return super.onCreateView(inflater, container, savedInstanceState);
    }


    public void deleteAll() {
        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
        dbHelper.open();
        dbHelper.deleteAll();
        dbHelper.close();
        refreshCourses();
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        setRetainInstance(true); // save fragment across config changes
        ma = (MainActivity) getActivity();
        ma.hideAddButton(false);
        ma.hideSaveButton(true);

        // FANCY setEmptyText("Click the add button to insert a course!");
        clf_View = getListView();
        clf_View.setOnItemClickListener(viewCourseListener);
        clf_View.setOnItemLongClickListener(viewAssignmentListener);
        clf_View.setSelector(R.drawable.list_item_selector);

        int[] resultView = new int[]{android.R.id.text1};
        String[] nameColumn = new String[]{KEY_NAME};

        cursorAdapter = new SimpleCursorAdapter(getActivity(),
                android.R.layout.simple_list_item_1, null, nameColumn, resultView, 0);
        setListAdapter(cursorAdapter);
    }

    private final OnItemClickListener viewCourseListener = new OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view,
                                int position, long id) {
            Log.w("LIST VIEW1", "Long id =" + id + "position:" + position);
            view.setSelected(true);
            clf_listener.onSelect(id); // pass selection to MainActivity
        }

    };

    private final OnItemLongClickListener viewAssignmentListener = new OnItemLongClickListener() {
        @Override
        public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
            clf_listener.onLongSelect(id);
            view.setSelected(true);


            return true;
        }
    };

    @Override
    public void onResume() {
        super.onResume();
        new GetCoursesFromDB().execute("");


    }

    private class GetCoursesFromDB extends AsyncTask<String, Integer, Cursor> {
        final DatabaseHelper dbHelper = new DatabaseHelper(getActivity());

        @Override
        protected Cursor doInBackground(String... params) {
            dbHelper.open();
            Cursor cursor = dbHelper.getAllCourses();
            return cursor;
        }

        //TODO implement change cursor
        @Override
        protected void onPostExecute(Cursor cursor) {

            cursorAdapter.changeCursor(cursor);
            dbHelper.close();
        }
    }

    public void getCourses() {
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {

            getFragmentManager().popBackStack();
        }
        getFragmentManager().popBackStack();

        new getCanvasCourses().execute("");
    }

    //Kill the cursor
    public void onStop() {
        Cursor cursor = cursorAdapter.getCursor();
        cursorAdapter.swapCursor(null);
        if (cursor != null) {
            cursor.close();
        }
        super.onStop();
    }


    public class getCanvasCourses extends AsyncTask<String, Integer, String> {
        final DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
        String rawJSON = "";
        int stat;

        //Send result to onPost execute
        @Override
        protected String doInBackground(String... params) {
            try {
                URL url = new URL("https://weber.instructure.com/api/v1/courses");
                HttpsURLConnection conn = (HttpsURLConnection) url.openConnection();
                conn.setRequestMethod("GET");
                conn.setRequestProperty("Authorization", "Bearer " + MainActivity.AUTH_TOKEN);
                conn.connect();
                Log.w("CLF - ", url.toString());
                int status = conn.getResponseCode();
                if (status < 199 || status > 202) {
                    stat = status;
                }
                switch (status) {
                    case 200:
                    case 201:
                        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                        rawJSON = br.readLine();
                        Log.w("RAQ _--------------", rawJSON);
                }
            } catch (MalformedURLException e) {
                Log.w("MUE _--------------", e.getMessage());
            } catch (IOException e) {
                Log.w("IOE _--------------", e.getMessage());
            }

            return rawJSON;
        }

        @Override
        protected void onPostExecute(String result) {
            super.onPostExecute(result);
            dbHelper.open();
            try {
                CanvasObjects.Course[] courses = jsonParse(result);
                for (CanvasObjects.Course course : courses) {
                    dbHelper.insertCourse(course.id, course.name, course.course_code, course.start_at, course.end_at);
                }
            } catch (Exception e) {

            }
            refreshCourses();
            ma.toastGTFO(stat, 1);
            dbHelper.close();
        }
    }


    private CanvasObjects.Course[] jsonParse(String rawJson) {
        GsonBuilder gsonb = new GsonBuilder();
        Gson gson = gsonb.create();

        CanvasObjects.Course[] courses = null;

        try {
            courses = gson.fromJson(rawJson, CanvasObjects.Course[].class);
        } catch (Exception e) {

        }
        return courses;
    }


    public void refreshCourses() {
        new GetCoursesFromDB().execute("");
    }


}
