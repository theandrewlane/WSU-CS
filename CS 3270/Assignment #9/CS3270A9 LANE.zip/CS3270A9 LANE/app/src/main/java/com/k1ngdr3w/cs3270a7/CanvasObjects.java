package com.k1ngdr3w.cs3270a7;


/**
 * Created by k1ngdr3w on 6/8/15.
 */
public class CanvasObjects {


    class Course {
        String id;
        protected String sis_course_id;
        String name;
        String course_code;
        protected String account_id;
        String start_at;
        String end_at;
        protected Enrollment[] enrollments;
        protected Calendar calendar;
        protected String syllabus_body;
        protected String needs_grading_count;
        protected Term term;
    }

    protected class Term {
        protected String id;
        protected String name;
        protected String start_at;
        protected String end_at;
    }

    protected class Calendar {
        protected String ics;
    }

    protected class Enrollment {
        protected String type;
        protected String role;
        protected String computed_final_score;
        protected String computed_current_score;
        protected String computed_final_grade;
    }


}
