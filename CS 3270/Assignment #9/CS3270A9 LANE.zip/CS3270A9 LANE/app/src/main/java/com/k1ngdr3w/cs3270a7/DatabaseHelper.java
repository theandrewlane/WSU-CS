package com.k1ngdr3w.cs3270a7;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Created by k1ngdr3w on 6/1/16.
 */
class DatabaseHelper {

    private static final String TAG = "DBAdapter"; //used for logging database version changes

    //Field Names:
    public DatabaseHelper(Context context) {
        // create a new DatabaseOpenHelper
        dboh = new DatabaseOpenHelper(context, DATABASE_NAME, null, 1);
    }

    //DataBase info:
    private static final String DATABASE_NAME = "CS3270A7";
    private static final String DATABASE_TABLE = "COURSES";
    public static final int DATABASE_VERSION = 2; //FOR UPDATEs

    private SQLiteDatabase sqlDb;
    private final DatabaseOpenHelper dboh;

    //DONT GET THESE MESSED UP DUDE
    private final String KEY_ROWID = "_id";
    private final String KEY_COURSEID = "id";
    private final String KEY_COURSECODE = "course_code";
    private final String KEY_NAME = "name";
    private final String KEY_STARTAT = "start_at";
    private final String KEY_ENDAT = "end_at";

    private final String[] ALL_KEYS = new String[]{KEY_ROWID, KEY_COURSEID, KEY_NAME, KEY_COURSECODE, KEY_STARTAT, KEY_ENDAT};

    //SQL statement to create database
    private final String DATABASE_CREATE_SQL =
            "CREATE TABLE " + DATABASE_TABLE
                    + " (" + KEY_ROWID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                    + KEY_COURSEID + " TEXT, "
                    + KEY_NAME + " TEXT, "
                    + KEY_COURSECODE + " TEXT, "
                    + KEY_STARTAT + " TEXT, "
                    + KEY_ENDAT + " TEXT "
                    + ");";


    public SQLiteDatabase open() throws SQLiteException {
        sqlDb = dboh.getWritableDatabase();
        return sqlDb;
    }

    public void close() {
        if (sqlDb != null)
            sqlDb.close();
    }


    // Delete a row from the database, by rowId (primary key)
    public boolean deleteRow(long rowId) {
        String where = KEY_ROWID + "=" + rowId;
        return sqlDb.delete(DATABASE_TABLE, where, null) != 0;
    }

    public void updateCourse(long id, String cid, String n, String c, String s, String e) {
        Log.w("CS3287 ____-----______!", "sqlDb helper updateCourse the course:\nROW_ID: " + id + "\ncourseID: " + cid + "\ncourse Name: " + n + "\nCourse Code: " + c + "\nstart/end at " + s + "/" + e);
        ContentValues updateCourse = new ContentValues();
        updateCourse.put(KEY_COURSEID, cid);
        updateCourse.put(KEY_NAME, n);
        updateCourse.put(KEY_COURSECODE, c);
        updateCourse.put(KEY_STARTAT, s);
        updateCourse.put(KEY_ENDAT, e);
        open();
        sqlDb.update(DATABASE_TABLE, updateCourse, "_id=" + id, null);
        close();
    }

    public void deleteAll() {
        Cursor c = getAllCourses();
        long rowId = c.getColumnIndexOrThrow(KEY_ROWID);
        if (c.moveToFirst()) {
            do {
                deleteRow(c.getLong((int) rowId));
            } while (c.moveToNext());
        }
        c.close();
    }

    public long insertCourse(String id, String n, String c, String s, String e) {
        long rowID;
        Log.d("CS3287 ____-----______!", "sqlDb helper Inserting the course:\ncourseID: " + id + "\ncourse Name: " + n + "\nCourse Code: " + c + "\nstart/end at " + s + "/" + e);
        ContentValues newCourse = new ContentValues();
        newCourse.put(KEY_COURSEID, id);
        newCourse.put(KEY_NAME, n);
        newCourse.put(KEY_COURSECODE, c);
        newCourse.put(KEY_STARTAT, s);
        newCourse.put(KEY_ENDAT, e);
        open();
        rowID = sqlDb.insert(DATABASE_TABLE, null, newCourse);
        close();
        return rowID;
    }


    public Cursor getOneCourse(long id) {
        Log.d("_____-------!", "sqlDb helper getOneCourse called once for the ID: " + id);
        String where = KEY_ROWID + "=" + id;
        Cursor c = 	sqlDb.query(true, DATABASE_TABLE, ALL_KEYS,
                where, null, null, null, null, null, null);

        if (c != null) {
            c.moveToFirst();
        }
        return c;
    }

    public Cursor getCourseId(long id) {
        Log.d("_____-------!", "sqlDb helper getOneCourse called once for the ID: " + id);
        String where = KEY_ROWID + "=" + id;
        String [] ONEKEY = {KEY_COURSECODE};
        Cursor c = 	sqlDb.query(true, DATABASE_TABLE, ONEKEY,
                where, null, null, null, null, null, null);

        if (c != null) {
            c.moveToFirst();
        }
        return c;
    }

    public Cursor getAllCourses() {
        String where = null;
        Cursor c = sqlDb.query(true, DATABASE_TABLE, ALL_KEYS, where, null, null, null, null, null, null);
        if (c != null) {
            c.moveToFirst();
        }
        return c;
    }


    private class DatabaseOpenHelper extends SQLiteOpenHelper {

        //Create a const from the DBH so it's always inst properly
        public DatabaseOpenHelper(Context context, String name,
                                  SQLiteDatabase.CursorFactory factory, int version) {
            super(context, name, factory, version);
        }


        @Override
        public void onCreate(SQLiteDatabase db) {
            Log.d("CS3287 ____-----______!", "CREATING THE DB YO!");
            db.execSQL(DATABASE_CREATE_SQL);
        }

        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            Log.d("CS3287 ____-----______!", "sqlDb helper onUpgrade");

        }
    }


}
