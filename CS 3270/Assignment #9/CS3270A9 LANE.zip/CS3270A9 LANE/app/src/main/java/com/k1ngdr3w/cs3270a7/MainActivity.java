package com.k1ngdr3w.cs3270a7;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.res.Configuration;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import com.google.android.gms.common.api.GoogleApiClient;

import org.joda.time.DateTime;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;


/**
 * Created by k1ngdr3w on 6/1/16.
 */
public class MainActivity extends AppCompatActivity implements CourseListFragment.CLF_Listener, CourseEditFragment.CEF_Listener, CourseViewFragment.CVF_Listener {

    /* ------------ AUTH TOKEN HERE!!! ----------------*/
    public static final String AUTH_TOKEN = "14~zbmH5qyKzefoXHjzaj6qCWiCvjmvNyy6gJ8Ioh8Z36TPIXs9Cq0NIU1TDroPAuhl";
  /* ------------ AUTH TOKEN HERE!!! ----------------*/


    private CourseEditFragment CEF;
    private CourseListFragment CLF;
    private CourseViewFragment CVF;
    private MenuItem del;
    private MenuItem im;
    private MenuItem back;
    private MenuItem edit;
    private AssignmentListFragment ALF;
    private Menu MENU;

    private final String KEY_ROWID = "_id";
    public String KEY_COURSEID = "id";
    public String KEY_COURSECODE = "course_code";
    public String KEY_NAME = "name";
    public String KEY_STARTAT = "start_at";
    public String KEY_ENDAT = "end_at";

    private int orientationView;

    private FragmentManager fragmentManager;
    private FragmentTransaction fragmentTransaction;
    /**
     * ATTENTION: This was auto-generated to implement the App Indexing API.
     * See https://g.co/AppIndexing/AndroidStudio for more information.
     */
    private GoogleApiClient client;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        orientationView = getResources().getConfiguration().orientation;


        setContentView(R.layout.activity_main);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_FORCE_NOT_FULLSCREEN);
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
        //Request keybaord
        InputMethodManager imm = (InputMethodManager) this.getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
        //This has already been created so GTFO
        if (savedInstanceState != null) {
            return;
        }

        if (findViewById(R.id.mainLayout) != null) {
            Log.d("MAIN ACT LOGGING GOO!", "Arguments for CVF: " + findViewById(R.id.mainLayout));
            CLF = new CourseListFragment();
            FragmentTransaction transaction = getFragmentManager().beginTransaction();
            transaction.add(R.id.mainLayout, CLF);
            transaction.commit();
        }

    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MENU = menu;
        menu.clear();
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menuicons, menu);
        del = menu.findItem(R.id.action_delete);
        im = menu.findItem(R.id.action_importCourses);
        edit = menu.findItem(R.id.action_Edit);
        back = menu.findItem(R.id.action_BackToList);
        del.setVisible(false);
        im.setVisible(true);
        edit.setVisible(false);
        back.setVisible(false);
        return true;
    }

    public void showImportMenuOption(boolean boo) {
        Log.e("import", String.valueOf(im.isVisible()));
        im.setVisible(boo);
    }

    public void showBackMenuOption(boolean boo) {
        back.setVisible(boo);
    }

    public void showEditMenuOption(boolean boo) {
        edit.setVisible(boo);
    }

    @Override
    protected void onResume() {
        super.onResume();
    }

    public String canvasDateConvert(String utcDate) {
        DateFormat f1 = new SimpleDateFormat("HH:mm:ss");
        DateFormat f2 = new SimpleDateFormat("h:mma");

        DateTime dateTime = new DateTime(utcDate);
        String weekDay = dateTime.dayOfWeek().getAsText();
        String month = dateTime.monthOfYear().getAsText();
        String day = dateTime.dayOfMonth().getAsText();
        String year = String.valueOf(dateTime.getYear());
        String time = (String.valueOf(dateTime.getHourOfDay()) + ":" + String.valueOf(dateTime.getMinuteOfHour() + ":00"));
        try {
            time = f2.format(f1.parse(time));
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return (weekDay + ", " + month + " " + day + ", " + year + " at " + time);
    }


    public void showListFragment() {
        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.hide(CVF);
        fragmentTransaction.hide(CEF);
        fragmentTransaction.commit();

    }

    public void showEditFragment() {
        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.hide(CVF);
        fragmentTransaction.hide(CLF);
        fragmentTransaction.commit();

    }

    public void showViewFragment() {
        fragmentManager = getFragmentManager();
        fragmentTransaction = fragmentManager.beginTransaction();
        fragmentTransaction.hide(CLF);
        fragmentTransaction.hide(CEF);
        fragmentTransaction.commit();
    }


    //Called after a new course has been updated/created, pops back to CLV
    @Override
    public void onComplete(long rowID) {
        hideSaveButton(true);
        hideAddButton(false);
        getFragmentManager().popBackStack();
        getFragmentManager().popBackStack();
        CLF.refreshCourses();

    }


    @Override
    public void onAdd() {
        hideSaveButton(false);
        hideAddButton(true);
        CEF = new CourseEditFragment();
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        //Port
        if (orientationView == 1) {
            fragmentTransaction.replace(R.id.mainLayout, CEF);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

        }
        //Land
        if (orientationView == 2) {
            fragmentTransaction.replace(R.id.detailscontainer, CEF);
            fragmentTransaction.addToBackStack(null);
            showBackMenuOption(false);
            fragmentTransaction.commit();
        }


    }

    //When user selects item on listview, this should hide the mainlayout and show the CVF
    @Override
    public void onSelect(long rowID) {
        hideSaveButton(true);
        hideAddButton(true);
        CVF = new CourseViewFragment();
        Bundle arguments = new Bundle();
        arguments.putLong(KEY_ROWID, rowID);
        CVF.setArguments(arguments);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        //Portrait
        if (orientationView == 1) {
            fragmentTransaction.replace(R.id.mainLayout, CVF);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

        }
        //Land
        if (orientationView == 2) {
            fragmentTransaction.replace(R.id.detailscontainer, CVF);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();
            showBackMenuOption(false);
        }
    }

    //calls the assignments api and populates LV
    @Override
    public void onLongSelect(long rowID) {
        hideSaveButton(true);
        hideAddButton(true);

        ALF = new AssignmentListFragment();
        Bundle arguments = new Bundle();
        arguments.putLong(KEY_ROWID, rowID);
        ALF.setArguments(arguments);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();
        //Port
        if (orientationView == 1) {
            fragmentTransaction.replace(R.id.mainLayout, ALF);
            fragmentTransaction.addToBackStack(null);
            fragmentTransaction.commit();

        }
        //Land
        if (orientationView == 2) {
            fragmentTransaction.replace(R.id.detailscontainer, ALF);
            fragmentTransaction.addToBackStack(null);
            showBackMenuOption(false);
            fragmentTransaction.commit();
        }


    }

    public void deleteAll() {
        CLF.deleteAll();

    }

    //When user confirms delete
    @Override
    public void onDelete() {
        getFragmentManager().popBackStack();
        getFragmentManager().popBackStack();
        hideAddButton(false);
        hideSaveButton(true);
        if (CLF != null)
            CLF.refreshCourses();
    }

    public void clearMenu() {
        MENU.clear();
    }

    //When user edits the course
    @Override
    public void onEdit(Bundle arguments) {
        MENU.clear();
        hideSaveButton(false);
        hideAddButton(true);
        CEF = new CourseEditFragment();
        CEF.setArguments(arguments);
        FragmentTransaction fragmentTransaction = getFragmentManager().beginTransaction();

        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            fragmentTransaction.replace(R.id.mainLayout, CEF);
            fragmentTransaction.addToBackStack(null);
            showBackMenuOption(true);

        } else {
            fragmentTransaction.replace(R.id.detailscontainer, CEF);
            fragmentTransaction.addToBackStack(null);
            showBackMenuOption(false);

        }
        fragmentTransaction.commit();
        showImportMenuOption(false);

    }

    @Override
    public void onImport() {

        CLF.getCourses();
    }


    public void onClick_AddNewCourse(View view) {
        onAdd();
    }

    public void onClick_SaveCourse(View view) {

        boolean saveSuccess;
        saveSuccess = CEF.runSave();
        if (saveSuccess) {
            hideSaveButton(true);
            hideAddButton(false);
        }
        // CLF.refreshCourses();

    }

    public void hideAddButton(boolean hide) {
        View b = findViewById(R.id.addButton);
        if (b != null && hide) {
            b.setVisibility(View.INVISIBLE);
        }
        if (b != null && !hide) {
            b.setVisibility(View.VISIBLE);
        }
    }

    public void hideSaveButton(boolean hide) {
        View b = findViewById(R.id.saveButton);
        if (b != null && hide) {
            b.setVisibility(View.INVISIBLE);
        }
        if (b != null && !hide) {
            b.setVisibility(View.VISIBLE);
        }
    }

    //Defined in menu xml, executed when import button is clicked.
    public void importCanvasCourses(MenuItem item) {
        CLF.getCourses();
    }

    public void goBackToListView(MenuItem item) {
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_PORTRAIT) {
            getFragmentManager().popBackStack();
            getFragmentManager().popBackStack();
        }
        hideAddButton(false);
        hideSaveButton(true);
        showBackMenuOption(false);
        showImportMenuOption(true);
    }

    public void toastGTFO(int status, int frag) {
        if ((status < 199 || status > 201) && status != 0) {
            Toast.makeText(this, "Got HTTP:" + String.valueOf(status) + " on this request, check your token and try again later.",
                    Toast.LENGTH_LONG).show();
        } else {
            if (frag == 1) {
                Toast.makeText(this, "Successfully imported canvas courses!",
                        Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Successfully imported assignments for selected course!",
                        Toast.LENGTH_LONG).show();
            }
        }
    }

    @Override
    public void onStart() {
        super.onStart();

    }

    @Override
    public void onStop() {
        super.onStop();

    }

}

