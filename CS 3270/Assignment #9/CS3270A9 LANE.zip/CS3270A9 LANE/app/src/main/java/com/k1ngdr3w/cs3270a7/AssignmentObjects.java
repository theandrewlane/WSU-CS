package com.k1ngdr3w.cs3270a7;


/**
 * Created by k1ngdr3w on 6/8/15.
 */
class AssignmentObjects {

    class Assignment {
        protected String id;
        protected String description;
        String due_at;

        String points_possible;

        String name;

    }

}
