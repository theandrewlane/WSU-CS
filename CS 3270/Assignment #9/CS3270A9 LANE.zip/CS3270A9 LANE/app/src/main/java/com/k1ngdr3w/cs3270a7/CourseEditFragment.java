package com.k1ngdr3w.cs3270a7;


import android.app.Activity;
import android.app.Fragment;
import android.content.Context;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class CourseEditFragment extends Fragment {

    private EditText edit_id, edit_name, edit_courseCode, edit_startAt, edit_endAt;
    String cid;
    String name;
    String courseCode;
    String startAt;
    String endAt;
    private String state;
    private long rowID;
    private CEF_Listener cef_listener;

    private MainActivity ma;
    private final String KEY_ROWID = "_id";
    private final String KEY_COURSEID = "id";
    private final String KEY_COURSECODE = "course_code";
    private final String KEY_NAME = "name";
    private final String KEY_STARTAT = "start_at";
    private final String KEY_ENDAT = "end_at";

    //Called to refresh CLV
    public interface CEF_Listener {
        void onComplete(long rowID);
    }

    public CourseEditFragment() {
        // Required empty public constructor
    }


    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        cef_listener = (CEF_Listener) activity;
    }



 /*   public void populateCourse(long id)
    {
        DatabaseHelper dbHelper = new DatabaseHelper(getActivity(), DatabaseHelper.DATABASE_TABLE, null, 1);
        Cursor cursor = dbHelper.getOneCourse(id); 
        cursor.moveToFirst(); //This is essential and often missed

         cid = cursor.getString(cursor.getColumnIndex(dbHelper.KEY_ROWID));
         name = cursor.getString(cursor.getColumnIndex(dbHelper.KEY_NAME));
         courseCode = cursor.getString(cursor.getColumnIndex(dbHelper.KEY_COURSECODE));
         startAt = cursor.getString(cursor.getColumnIndex(dbHelper.KEY_STARTAT));
         endAt = cursor.getString(cursor.getColumnIndex(dbHelper.KEY_ENDAT));

        edit_id.setText(cid);
        edit_name.setText(name);
        edit_courseCode.setText(courseCode);
        edit_startAt.setText(startAt);
        edit_endAt.setText(endAt);
    }*/

    //TODO FIND SOMETHING MROE ELEGANT
    @Override
    public void onPrepareOptionsMenu(Menu menu) {
        super.onPrepareOptionsMenu(menu);
        menu.clear();

        MenuItem item3 = menu.findItem(R.id.action_delete);
        MenuItem item2 = menu.findItem(R.id.action_importCourses);
        MenuItem item = menu.findItem(R.id.action_Edit);
        MenuItem item4 = menu.findItem(R.id.action_BackToList);
        item3.setVisible(false);
        item2.setVisible(false);
        item.setVisible(true);
        item4.setVisible(true);

    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(false);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        setRetainInstance(true);
        ma = (MainActivity) getActivity();

        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.toggleSoftInput(InputMethodManager.SHOW_FORCED, InputMethodManager.HIDE_IMPLICIT_ONLY);
        ma.showImportMenuOption(false);
        View rv = inflater.inflate(R.layout.fragment_course_edit, container, false);
        edit_id = (EditText) rv.findViewById(R.id.textField_CourseId);
        edit_name = (EditText) rv.findViewById(R.id.textField_CourseName);
        edit_courseCode = (EditText) rv.findViewById(R.id.textField_CourseCode);
        edit_startAt = (EditText) rv.findViewById(R.id.textField_StartAt);
        edit_endAt = (EditText) rv.findViewById(R.id.textField_EndAt);
        Bundle savedData = getArguments();
        //This means were editing not creating
        if (savedData != null) {
            state = "edit";
            Bundle arguments = getArguments();

            rowID = arguments.getLong("_id");
            Log.d("ROW ____-----______!", String.valueOf(rowID));

            rowID = savedData.getLong(KEY_ROWID);
            edit_id.setText(savedData.getString(KEY_COURSEID));
            edit_name.setText(savedData.getString(KEY_NAME));
            edit_courseCode.setText(savedData.getString(KEY_COURSECODE));
            edit_startAt.setText(savedData.getString(KEY_STARTAT));
            edit_endAt.setText(savedData.getString(KEY_ENDAT));
        } else {
            state = "create";
        }
        return rv;
    }


    private void updateAdd() {
        DatabaseHelper dbHelper = new DatabaseHelper(getActivity());
        if (state == "create") {
            Log.d("Edit CREATE!", "\ncourseID: " + edit_id.getText() + "\ncourse Name: " +
                    edit_name.getText() + "\nCourse Code: " + edit_courseCode + "\nstart/end at " + edit_startAt.getText() + "/" + edit_endAt.getText());
            rowID = dbHelper.insertCourse(edit_id.getText().toString(), edit_name.getText().toString(), edit_courseCode.getText().toString(), edit_startAt.getText().toString(), edit_endAt.getText().toString());
        }

        if (state == "edit") {

            Bundle arguments = getArguments();
            rowID = arguments.getLong("_id");
            Log.d("Edit UPDATE!", "e:\nROW_ID: " + rowID + "\ncourseID: " + edit_id.getText() + "\ncourse Name: " +
                    edit_name.getText() + "\nCourse Code: " + edit_courseCode + "\nstart/end at " + edit_startAt.getText() + "/" + edit_endAt.getText());
            //Grab the ID
            dbHelper.updateCourse(rowID, edit_id.getText().toString(), edit_name.getText().toString(), edit_courseCode.getText().toString(), edit_startAt.getText().toString(), edit_endAt.getText().toString());

        }
    }


    public boolean runSave() {
        //Make sure there is a value for everything or don't let them save
        if (edit_name.getText().toString().trim().length() > 0) {
            AsyncTask<Object, Object, Object> editCreateTask =
                    new AsyncTask<Object, Object, Object>() {
                        @Override
                        protected Object doInBackground(Object... params) {
                            updateAdd();
                            return null;
                        }

                        @Override
                        protected void onPostExecute(Object result) {
                            //Written to the DB now notfivy main
                            cef_listener.onComplete(rowID);
                        }
                    };
            editCreateTask.execute((Object[]) null);
            return true;
            //TODO Put a toast here for fails
        } else {
            Toast.makeText(getActivity(), "Name is a required field, please try again!",
                    Toast.LENGTH_LONG).show();
            return false;
        }
    }
}
