Video presentation can be found here: https://onedrive.live.com/redir?resid=4B8A41BD0BD596EA!26349&authkey=!AHmEvQHmovriW80&ithint=folder%2cpdf

Git Repository Can be Found here:https://github.com/theandrewlane/UAMS