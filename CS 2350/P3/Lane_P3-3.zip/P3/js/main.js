/**
 *
 * Andrew Lane
 * Project 3
 * 8/20/15
 * main.js
 * Supporting files: None
 *
 */


function moderation() {
    alert("Your comment:\n\"" + $('#comment').val() + "\"\nis pending moderator approval. Please check back soon");
    $('#comment').val('');
};

function contact (){
   return  alert("Thanks " + $('#name').val() + "!! \nYou'll be hearing from us soon");
}

var app = angular.module('beatsbydrew', ['ngRoute']).config(['$routeProvider', function ($routeProvider) {
    $routeProvider
        .when("/", {templateUrl: "pages/home.html", controller: "PageCtrl"})
        .when("/hip-hop", {templateUrl: "pages/hip-hop.html", controller: "PageCtrl"})
        .when("/hip-hop_detail", {templateUrl: "pages/hip-hop_detail.html", controller: "PageCtrl"})
        .when("/electronic", {templateUrl: "pages/electronic.html", controller: "PageCtrl"})
        .when("/electronic_detail", {templateUrl: "pages/electronic_detail.html", controller: "PageCtrl"})
        .when("/contact", {templateUrl: "pages/contact.html", controller: "PageCtrl"})
}]);

app.controller('PageCtrl', function () {
    //todo
});

app.run(function ($rootScope, $location, $route, $timeout) {
    $rootScope.config = {};
    $rootScope.config.app_url = $location.url();
    $rootScope.config.app_path = $location.path();
    $rootScope.layout = {};
    $rootScope.layout.loading = false;
    $rootScope.$on('$routeChangeStart', function () {
        console.log('$routeChangeStart');
        //show loading gif
        $timeout(function () {
            $rootScope.layout.loading = true;
        });
    });
    $rootScope.$on('$routeChangeSuccess', function () {
        console.log('$routeChangeSuccess');
        //hide loading gif
        $timeout(function () {
            $rootScope.layout.loading = false;
        }, 1000);
    });
});

