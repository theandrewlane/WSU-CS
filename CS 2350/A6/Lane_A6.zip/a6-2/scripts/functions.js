/*

 Assignment 7
 Andrew Lane
 Date:  July 3rd, 2015
 Filename: function.js

---------------------------

   Function List:
   showQuiz()
   Displays the questions in the exam

   hideQuiz()
      Used to hide the quiz questions

   stopClock()
      Used to stop the clock and grade the quiz and disable the exam

    runClock()
      update the time value in the page's clock
*/
var seconds = 0;
var clockId;
var quizclock;

function showQuiz() {
   document.getElementById("quiztable").style.visibility="visible";
}

function hideQuiz() {
   document.getElementById("quiztable").style.visibility="hidden";
}

function runClock() {
   seconds++;
   document.quiz.quizclock.value= seconds;
}

function startClock() {
   showQuiz();
   clockId = setInterval ("runClock()",1000);
}

function stopClock() {
   clearInterval (clockId);
   correctAns = gradeQuiz();
   alert("You have " + correctAns + " correct of 5 in " + seconds + " seconds.");
}

function gradeQuiz() {
   correct=0;
   if (document.quiz.q1[2].checked) correct++;
   if (document.quiz.q2[0].checked) correct++;
   if (document.quiz.q3[3].checked) correct++;
   if (document.quiz.q4[0].checked) correct++;
   if (document.quiz.q5[3].checked) correct++;
   
   document.getElementById("cor1").style.backgroundColor="yellow";
   document.getElementById("cor2").style.backgroundColor="yellow";
   document.getElementById("cor3").style.backgroundColor="yellow";
   document.getElementById("cor4").style.backgroundColor="yellow";
   document.getElementById("cor5").style.backgroundColor="yellow";

   for (i=0; i<document.quiz.elements.length; i++) document.quiz.elements[i].disabled=true;

   return correct;
}
