 function notrequired() {
    alert("This assignment didn't explicitly require me to update the sitemap, although I did anyway :)");
  }
   function notrequired2() {
    alert("This assignment didn't explicitly require me to update the storyboard :)");
  }

var x = document.getElementById("contactForm");
var makeForm = document.createElement('form');
makeForm.setAttribute("action", "");
makeForm.setAttribute("method", "post");
x.appendChild(makeForm);
var namelabel = document.createElement('label');
namelabel.innerHTML = "Name: ";
makeForm.appendChild(namelabel);
var inputelement = document.createElement('input');
inputelement.setAttribute("type", "text");
inputelement.setAttribute("name", "name");
inputelement.placeholder= "Your name...";
makeForm.appendChild(inputelement);
var linebreak = document.createElement('br');
makeForm.appendChild(linebreak);
var emaillabel = document.createElement('label');
emaillabel.innerHTML = "Email: ";
makeForm.appendChild(emaillabel);
var emailelement = document.createElement('input');
emailelement.setAttribute("type", "text");
emailelement.setAttribute("name", "email");
emailelement.placeholder= "Your email...";
makeForm.appendChild(emailelement);
var emailbreak = document.createElement('br');
makeForm.appendChild(emailbreak);
var messagelabel = document.createElement('label');
messagelabel.innerHTML = "Message: ";
makeForm.appendChild(messagelabel);
var texareaelement = document.createElement('textarea');
texareaelement.setAttribute("name", "message");
texareaelement.placeholder= "Compose a message...";
makeForm.appendChild(texareaelement);
var messagebreak = document.createElement('br');
makeForm.appendChild(messagebreak);
var submitelement = document.createElement('input');
submitelement.setAttribute("type", "submit");
submitelement.setAttribute("name", "submit");
submitelement.setAttribute("value", "Contact Me");
makeForm.appendChild(submitelement);

