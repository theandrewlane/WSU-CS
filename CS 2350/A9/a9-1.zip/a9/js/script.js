/**
 *
 * Andrew Lane
 * Assignment 9
 * 7/24/15
 * script.html
 * Supporting files: andrew.html, career.html, planetearth.html, script.js, styles.css
 *
 */

$(document).ready(function(){
	var Tabs = {
		'Andrew'	: 'pages/andrew.html',
		'Career'	: 'pages/career.html',
		'Planet Earth'	: 'pages/planetearth.html',
	}
	var colors = ['blue','green','red'];
	var topLineColor = {
		blue:'lightblue',
		green:'lightgreen',
		red:'red',
	}
	var z=0;
	$.each(Tabs,function(i,j){
		var tmp = $('<li><a href="#" class="tab '+colors[(z++%4)]+'">'+i+' <span class="left" /><span class="right" /></a></li>');
		tmp.find('a').data('page',j);
		$('ul.tabContainer').append(tmp);
	})
	$('.tab').click(function(e){
		/* "this" points to the clicked tab hyperlink: */
		var element = $(this);
		/* If it is currently active, return false and exit: */
		if(element.find('#overLine').length) return false;
		/* Detecting the color of the tab (it was added to the class attribute in the loop above): */
		var bg = element.attr('class').replace('tab ','');
		$('#overLine').remove();
		$('<div>',{
			id:'overLine',
			css:{
				display:'none',
				width:element.outerWidth()-2,
				background:topLineColor[bg] || 'white'
			}}).appendTo(element).fadeIn('slow');
			$.get(element.data('page'),function(msg){
				$('#contentHolder').html(msg);
			});
	})
	$('.tab').eq(0).click();
});
