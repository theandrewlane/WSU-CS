/*
 Andrew Lane
 Assignment 10
 7/31/15
 form.js
 */

$(document).ready(function () {

    $("#draggable").draggable().resizable();
    $("#slider").slider();

    $("#plang").autocomplete({
        source: ["c++", "java", "php", "angularJS", "reactJS", "python", "coldfusion", "javascript", "asp", "ruby"]
    });

    $("#datepicker").datepicker();


    $("input[type=submit]")
        .button()
        .click(function (event) {
            event.preventDefault();
        });

    $('#dlog').dialog('open');


    $("#wrapper").dialog({
        autoOpen: false,
        maxWidth: 600,
        maxHeight: 500,
        width: 600,
        height: 500,
        modal: true,
        buttons: {
            "Close": function () {
                $(this).dialog("close");
            }
        }
    });

    $('#submit').click(function () {
        $("#wrapper").animate({
            width: "100%",
            fontSize: "1em",
            borderWidth: "10px"
        }, 1500);
        $('#wrapper').dialog('open');
//                  return false;
    });

    $(function () {
        // run the currently selected effect
        function runEffect() {
            // get effect type from
            var selectedEffect = $("#effectTypes").val();

            // most effect types need no options passed by default
            var options = {};
            // some effects have required parameters
            if (selectedEffect === "scale") {
                options = {percent: 0};
            } else if (selectedEffect === "transfer") {
                options = {to: "#button", className: "ui-effects-transfer"};
            } else if (selectedEffect === "size") {
                options = {to: {width: 200, height: 60}};
            }

            // run the effect
            $("#effect").effect(selectedEffect, options, 500, callback);
        };

        // callback function to bring a hidden box back
        function callback() {
            setTimeout(function () {
                $("#effect").removeAttr("style").hide().fadeIn();
            }, 1000);
        };

        // set effect from select menu value
        $("#button").click(function () {
            runEffect();
            $("#wrapper").dialog('close');
            return false;
        });
    });
});




