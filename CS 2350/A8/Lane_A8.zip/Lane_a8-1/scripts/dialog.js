/**
 * Assignment 7
 * Andrew Lane
 * 7/15/15
 *
 * @type {string}
 */


var p1= "The most famous of fictional detectives, Sherlock Holmes first appeared in print in 1887, in stories written by the Scottish author and physician, Sir Arthur Conan Doyle. Holmes is famous for his use of deductive reasoning to solve difficult and complex cases. Almost all Holmes stories are told in the first-person narration of Dr. John Watson, Holmes' closest friend and confidant.";
var p2 = "Doyle wrote four novels and 56 short stories in the Sherlock Holmes canon. The first Holmes tale was the novel, A Study in Scarlet, which chronicled the meeting of Holmes and Watson and covered their first case together. As Doyle wrote additional tales, the Sherlock Holmes stories grew in popularity, becoming a regular feature of The Strand Magazine. Desiring to explore other literary pursuits, Doyle grew tired of the detective and killed off Holmes in the short story The Final Problem. However, public acclaim and a desire for more Holmes stories eventually persuaded Doyle to resurrect the popular detective, bringing him back in The Adventure of the Empty House.";
var p3 = "Doyle's final Holmes story, His Last Bow, appeared in 1914, but that did not end the public's fascination with Holmes and Watson. Basil Rathbone brought the character to the silver screen in 14 movies loosely based on Doyle's original stories. In more recent years, Jeremy Brett played Holmes to great critical acclaim over four seasons of  the BBC series, The Adventures of Sherlock Holmes. In all, Holmes has been played by over 70 actors appearing in over 200 films.";
var alertMessage = "Please actually add a paragraph, you're currently trying to add an empty string!"


$(document).ready(function() {
    $("body").css('background-color', '#339933');
    $("body").css('text-align','center');
    $("#h1").attr('style','margin-bottom:1em');
    $("#p2").css('display', 'none');

    //Append the text to each paragraph and set styles
    $("#p1").append(p1);
    $("#p1").attr('style','margin-bottom:1em');
    $("#p3").append(p3);
    $("#p3").attr('style','margin-bottom:auto; margin-top:1em');
    $('#ta').attr('style','height:90%;width:98%; margin:auto; margin:auto;');
    $(function() {
        $("#dialog").dialog({
            autoOpen: false
        });
        $(document).one("mousemove", function () {
            if (confirm('Select [OK] if you like to some text between these paragraphs.')) {
                $("#dialog").dialog({
                    height: 500,
                    scrollable: false,
                    width: 500,
                    modal: true,
                    resizable: false
                });
                $("#dialog").dialog('open');
                $("#ta").append(p2);
            }
            });
    });

    //Check if the user's input is not blank
    $("#submit").click(function() {
        if ( $('#ta').val() === '' ||$('#ta').val() === null ) {
            alert(alertMessage);
        }
        else {
            $("#p2").append($('#ta').val());
            $("#p2").css('display', 'block');

            $("#dialog").dialog('close');
        }
    });

    $("#p2").on("mouseenter", function() {
        if($('#p2').text().length > 1 ){
            $('#p2').attr('style', 'color:#0066CC');
        }
    });
    $("#p2").on("mouseleave", function() {
        if($('#p2').text().length > 1 ){
            $('#p2').attr('style', 'color:white');
        }
    });
    $("#p1").on("mouseenter", function() {
        if($('#p1').text().length > 1 ){
            $('#p1').css('color', 'red');
        }
    });
    $("#p1").on("mouseleave", function() {
        if($('#p1').text().length > 1 ){
            $('#p1').css('color','white');
        }
    });
    $("#p3").on("mouseenter", function() {
        if($('#p3').text().length > 1 ){
            $('#p3').css('color','#006600');
        }
    });
    $("#p3").on("mouseleave", function() {
        if($('#p3').text().length > 1 ){
            $('#p3').css('color', 'white');
        }
    });
});