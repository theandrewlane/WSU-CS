To use, specify twitter credentials in .tss-live-credentials and specify keys in .tss-live-keys.

To build JSON libs and compile this program, you need GCC/G++ 4.9 or greater

                                                                                                                 sudo add-apt-repository ppa:ubuntu-toolchain-r/test
                                                                                                                 sudo apt-get update
                                                                                                                 sudo apt-get install gcc-4.9 g++-4.9
                                                                                                                 sudo update-alternatives --install /usr/bin/gcc gcc /usr/bin/gcc-4.9 60 --slave /usr/bin/g++ g++ /usr/bin/g++-4.9